
import java.awt.Dimension;
import java.awt.Toolkit;
//import java.awt.*;

import com.itextpdf.text.*;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.pdf.PdfWriter;

import java.io.FileOutputStream;
import java.io.IOException;
//import java.lang.Object;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/*
 * NewJFrame.java
 *
 * Created on 27-gen-2010, 19.22.34
 */

/**
 *
 * @author Gianluigi
 */;

public class NewJFrame extends javax.swing.JFrame {
    private int totaleAlunni=0;
    private int nAlunno=0;
    private String [] ConoscenzeList = new String[7];
    private String [] CompComprList = new String[6];
    private String [] CompCoerList = new String[6];
    private String [] CompEspList = new String[6];
    private String [] CompLingList = new String[6];
    private String [] CapAnAppl = new String[6];
    private String [] CapAut = new String[5];
    private String [] ValProva = new String[4];
    private String [] TipologiaProva = new String[7];
    private String [] Voto = new String[11];
    private String Argomenti;

    private StrutturaDati st;
    LeggeListaNomi r = new LeggeListaNomi();
    LeggeListaNomi recupero = new LeggeListaNomi();
    ScriviFile w = new ScriviFile("Recupero.dat");
    ScriviFile ww = new ScriviFile("FilePerExcel.dat");
    

    /** Creates new form NewJFrame */
    public NewJFrame() {
        initComponents();
        inizia();
        //w.scrivi("ciao a tutti");
    }

    public void inizia() {
        //Conoscenze
        ConoscenzeList[0]="--- Selezionare ---";
        ConoscenzeList[1]="nulle";
        ConoscenzeList[2]="gravemente lacunose";
        ConoscenzeList[3]="limitate/parziali";
        ConoscenzeList[4]="essenziali";
        ConoscenzeList[5]="in parte complete";
        ConoscenzeList[6]="complete";
       
        //Competenze: comprensione
        CompComprList[0]="--- Selezionare ---";
        CompComprList[1]="limitata";
        CompComprList[2]="parziale";
        CompComprList[3]="essenziale";
        CompComprList[4]="discreta";
        CompComprList[5]="precisa";

        //Competenze: coerenza - aderenza
        CompCoerList[0]="--- Selezionare ---";
        CompCoerList[1]="occasionale";
        CompCoerList[2]="parziale";
        CompCoerList[3]="generale";
        CompCoerList[4]="globale";
        CompCoerList[5]="piena";

        //Competenze: esposizione
        CompEspList[0]="--- Selezionare ---";
        CompEspList[1]="confusa";
        CompEspList[2]="imprecisa";
        CompEspList[3]="semplice";
        CompEspList[4]="abbastanza chiara";
        CompEspList[5]="chiara";

        //Competenze: linguaggio specifico
        CompLingList[0]="--- Selezionare ---";
        CompLingList[1]="improprio";
        CompLingList[2]="impreciso";
        CompLingList[3]="elementare";
        CompLingList[4]="abbastanza appropriato";
        CompLingList[5]="appropriato";

        //Capacità: analisi ed applicazione
        CapAnAppl[0]="--- Selezionare ---";
        CapAnAppl[1]="confusa";
        CapAnAppl[2]="occasionale";
        CapAnAppl[3]="parziale";
        CapAnAppl[4]="generale";
        CapAnAppl[5]="globale";

        //Capacità: autonomia
        CapAut[0]="--- Selezionare ---";
        CapAut[1]="manca di autonomia";
        CapAut[2]="poca autonomia";
        CapAut[3]="spunti di autonomia";
        CapAut[4]="globale autonomia";

        //Valutazione complessiva della prova
        ValProva[0]="--- Selezionare ---";
        ValProva[1]="esito positivo";
        ValProva[2]="esito negativo";
        ValProva[3]="verifica non effettuata per assenza";

        //Tipologia della prova
        TipologiaProva[0]="--- Selezionare ---";
        TipologiaProva[1]="(*) Test";
        TipologiaProva[2]="(*) Quesiti";
        TipologiaProva[3]="(*) Risposte aperte";
        TipologiaProva[4]="(*) Questionario";
        TipologiaProva[5]="(*) Altro";
        TipologiaProva[6]="Orale";

        //Voto (solo per l'interrogazione orale)
        Voto[0]="--- Selezionare ---";
        Voto[1]="1/10";
        Voto[2]="2/10";
        Voto[3]="3/10";
        Voto[4]="4/10";
        Voto[5]="5/10";
        Voto[6]="6/10";
        Voto[7]="7/10";
        Voto[8]="8/10";
        Voto[9]="9/10";
        Voto[10]="10/10";

        //Sono invisibili fino a che non si seleziona la prova orale
        toggleComponenti(false);

        r.setNomeFile(jTextField3.getText());
        r.openListaNomi();
        r.readListaNomi();
        r.closeListaNomi();
        //System.out.println("--->>>"+r.getRiga(0));
        System.out.println("Ho letto Lista.txt per ottenere il Numero Reale di Alunni");
        //assegna il numero totale degli alunni all'oggetto st (StrutturaDati)
        totaleAlunni = r.getNumeroAlunni();
        st = new StrutturaDati(totaleAlunni);
        for (int k = 0; k < totaleAlunni; k++) {
            ScriviStrutturaDati(k, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "");
        }

        //Scrive il primo nome della lista nel form...
        jTextField1.setText(st.getNome(0));
        jTextField2.setText(st.getClasse(0));
        jComboBox1.setSelectedIndex(0);
        jComboBox2.setSelectedIndex(0);
        jComboBox3.setSelectedIndex(0);
        jComboBox4.setSelectedIndex(0);
        jComboBox5.setSelectedIndex(0);
        jComboBox6.setSelectedIndex(0);
        jComboBox7.setSelectedIndex(0);
        jComboBox8.setSelectedIndex(0);
        jComboBox9.setSelectedIndex(0);
        jComboBox10.setSelectedIndex(0);

        try {
            //Legge il file Recupero.dat
            recupero.setNomeFile(jTextField4.getText());
            recupero.openListaNomi();
            recupero.readListaNomi();
            recupero.closeListaNomi();
            System.out.println("Ho letto Recupero.dat ---> "+recupero.getNomeFile());
            System.out.println(">>>>>>>>>>>"+recupero.getRiga(0));
            for (int k=0; k<totaleAlunni; k++) {
                System.out.println("+++ "+k+" +++");
                Decodifica(k);
            }
            AggiornaForm(0);
            //StampaFileExcel();
            //StampaPdf();
            //StampaFileRecupero();
        }
        catch(Exception e) {
            System.out.println("Recupero.dat: Non ho trovato nessun File");
        }
    }

    public void StampaPdf() {
        String Titolo;
        String s1,s2,s3,s4,s5,s6;

        System.out.println("Stampa del file pdf: Recupero.pdf");
        Document document = new Document() {};
        try {
            PdfWriter.getInstance(document, new FileOutputStream("Recupero.pdf"));
            document.open();

            for(int k=0; k<totaleAlunni; k++) {
                Image X = Image.getInstance("Immagini/X.gif");
                X.scalePercent(10);
                //img.setAbsolutePosition(200, 400);
                //document.add(X);
                Image Q = Image.getInstance("Immagini/Q.gif");
                Q.scalePercent(10);
                //img.setAbsolutePosition(200, 400);
                //document.add(Q);
                
                document.add(new Paragraph(" "));
                Titolo="   VERIFICA E VALUTAZIONE INTERVENTI DI RECUPERO";
                Chunk uno = new Chunk(Titolo, new Font(Font.FontFamily.HELVETICA, 14, Font.BOLD));
                Image IIS_Orfini = Image.getInstance("Immagini/BN_IISOrfini.gif");
                IIS_Orfini.scalePercent(30);
                Chunk Orfini = new Chunk(IIS_Orfini,0,-10);
                document.add(Orfini); document.add(uno);

                //document.add(Chunk.NEWLINE);
                //document.add(new Paragraph("VERIFICA E VALUTAZIONE INTERVENTI DI RECUPERO"));
                //document.add(new Paragraph("INTERVENTI DI RECUPERO"));

                document.add(new Paragraph(" "));
                String sa="Alunno: ";
                String sa1=st.getNome(k);
                String sa2="               Classe: ";
                String sa3=st.getClasse(k);
                Chunk due = new Chunk(sa);
                Chunk tre = new Chunk(sa1, new Font(Font.FontFamily.HELVETICA, 12, Font.BOLD));
                Chunk quattro = new Chunk(sa2);
                Chunk cinque = new Chunk(sa3, new Font(Font.FontFamily.HELVETICA, 12, Font.BOLD));
                document.add(due); document.add(tre); document.add(quattro); document.add(cinque);
                document.add(Chunk.NEWLINE);
                //document.add(new Paragraph(" "));
                //document.add(new Paragraph("Alunno: " + st.getNome(k) + "               Classe: " + st.getClasse(k)));

                //Far leggere la disciplina dal form...
                String mat="CARENZA NELLA DISICIPLINA: ";
                String materia = jTextField5.getText();  //"Fisica e Lab.";
                Chunk m1 = new Chunk(mat);
                Chunk m2 = new Chunk(materia, new Font(Font.FontFamily.HELVETICA, 12, Font.BOLD));
                document.add(m1); document.add(m2);
                //document.add(new Paragraph("CARENZA NELLA DISICIPLINA: " + materia));

                document.add(new Paragraph(" "));
                String tip1="TIPOLOGIA DI VERIFICA";
                String tip2=" (scelta dal docente): ";
                String tip3=TipologiaProva[st.getTipologia_verifica(k)];
                String tip4="* la prova va allegata alla scheda ";
                String tip6="ARGOMENTI: ";
                String tip7=st.getArgomenti(k);
                String tip8="Voto: ";
                String tip9=st.getVoto(k) + "/10";
                Chunk t1=new Chunk(tip1, new Font(Font.FontFamily.HELVETICA, 12, Font.UNDERLINE));
                Chunk t2 = new Chunk(tip2);                
                document.add(t1); document.add(t2);
                document.add(Chunk.NEWLINE);
                Chunk t3 = new Chunk(tip3);
                document.add(t3);
                //document.add(new Paragraph("TIPOLOGIA DI VERIFICA (scelta dal docente): " + TipologiaProva[st.getTipologia_verifica(k)]));
                if (st.getTipologia_verifica(k) >= 1 && st.getTipologia_verifica(k) < 5) {
                    document.add(new Paragraph("* la prova va allegata alla scheda "));
                }
                if (st.getTipologia_verifica(k) == 6) {
                    document.add(new Paragraph("ARGOMENTI: " + st.getArgomenti(k)));
                    document.add(new Paragraph("Voto: " + st.getVoto(k) + "/10"));
                }
                document.add(new Paragraph(" "));
                String val1="VALUTAZIONE DELLA PROVA";
                String val2=" (mettere la crocetta alla voce corrispondente)";
                Chunk v1=new Chunk(val1, new Font(Font.FontFamily.HELVETICA, 12, Font.UNDERLINE));
                Chunk v2 = new Chunk(val2);
                document.add(v1); document.add(v2);
                document.add(Chunk.NEWLINE); document.add(Chunk.NEWLINE);
                //document.add(new Paragraph("VALUTAZIONE DELLA PROVA"));

                //ConoscenzeList[1..6];
                Titolo="Conoscenze:";
                s1=" nulle   ";
                s2=" gravemente lacunose   ";
                s3=" limitate/parziali   ";
                s4=" essenziali   ";
                s5=" in parte complete   ";
                s6=" complete";
                //....
                Chunk con0=new Chunk(Titolo, new Font(Font.FontFamily.HELVETICA, 12, Font.BOLD));
                document.add(con0); document.add(Chunk.NEWLINE);
                Chunk Quad = new Chunk(Q,0,0);
                Chunk Ics = new Chunk(X,0,0);

                Chunk con1 = new Chunk(s1);
                Chunk con2 = new Chunk(s2);
                Chunk con3 = new Chunk(s3);
                Chunk con4 = new Chunk(s4);
                Chunk con5 = new Chunk(s5);
                Chunk con6 = new Chunk(s6);
                if(st.getConoscenze(k)==1) {document.add(Ics); document.add(con1);}
                  else {document.add(Quad); document.add(con1);}
                if(st.getConoscenze(k)==2) {document.add(Ics); document.add(con2);}
                  else {document.add(Quad); document.add(con2);}
                if(st.getConoscenze(k)==3) {document.add(Ics); document.add(con3);}
                  else {document.add(Quad); document.add(con3);}
                if(st.getConoscenze(k)==4) {document.add(Ics); document.add(con4);}
                  else {document.add(Quad); document.add(con4);}
                if(st.getConoscenze(k)==5) {document.add(Ics); document.add(con5); document.add(Chunk.NEWLINE);}
                  else {document.add(Quad); document.add(con5); document.add(Chunk.NEWLINE);}
                if(st.getConoscenze(k)==6) {document.add(Ics); document.add(con6);}
                  else {document.add(Quad); document.add(con6);}
                document.add(Chunk.NEWLINE); document.add(Chunk.NEWLINE);
                //document.add(new Paragraph("Conoscenze: " + ConoscenzeList[st.getConoscenze(k)]));

                Titolo="Competenze: comprensione";
                Chunk comp01=new Chunk(Titolo, new Font(Font.FontFamily.HELVETICA, 12, Font.BOLD));
                document.add(comp01); document.add(Chunk.NEWLINE);
                s1=" limitata   ";
                s2=" parziale   ";
                s3=" essenziale   ";
                s4=" discreta   ";
                s5=" precisa   ";
                Chunk con01 = new Chunk(s1);
                Chunk con02 = new Chunk(s2);
                Chunk con03 = new Chunk(s3);
                Chunk con04 = new Chunk(s4);
                Chunk con05 = new Chunk(s5);
                Chunk con06 = new Chunk(s6);
                if(st.getCompetenze_comprensione(k)==1) {document.add(Ics); document.add(con01);}
                  else {document.add(Quad); document.add(con01);}
                if(st.getCompetenze_comprensione(k)==2) {document.add(Ics); document.add(con02);}
                  else {document.add(Quad); document.add(con02);}
                if(st.getCompetenze_comprensione(k)==3) {document.add(Ics); document.add(con03);}
                  else {document.add(Quad); document.add(con03);}
                if(st.getCompetenze_comprensione(k)==4) {document.add(Ics); document.add(con04);}
                  else {document.add(Quad); document.add(con04);}
                if(st.getCompetenze_comprensione(k)==5) {document.add(Ics); document.add(con05);}
                  else {document.add(Quad); document.add(con05);}
                document.add(Chunk.NEWLINE); document.add(Chunk.NEWLINE);
                //document.add(new Paragraph("Competenze - comprensione: " + CompComprList[st.getCompetenze_comprensione(k)]));

                Titolo="Competenze: coerenza - aderenza";
                Chunk comp001=new Chunk(Titolo, new Font(Font.FontFamily.HELVETICA, 12, Font.BOLD));
                document.add(comp001); document.add(Chunk.NEWLINE);
                s1=" occasionale   ";
                s2=" parziale   ";
                s3=" generale   ";
                s4=" globale   ";
                s5=" piena   ";
                Chunk con001 = new Chunk(s1);
                Chunk con002 = new Chunk(s2);
                Chunk con003 = new Chunk(s3);
                Chunk con004 = new Chunk(s4);
                Chunk con005 = new Chunk(s5);
                Chunk con006 = new Chunk(s6);
                if(st.getCompetenze_coerenza(k)==1) {document.add(Ics); document.add(con001);}
                  else {document.add(Quad); document.add(con001);}
                if(st.getCompetenze_coerenza(k)==2) {document.add(Ics); document.add(con002);}
                  else {document.add(Quad); document.add(con002);}
                if(st.getCompetenze_coerenza(k)==3) {document.add(Ics); document.add(con003);}
                  else {document.add(Quad); document.add(con003);}
                if(st.getCompetenze_coerenza(k)==4) {document.add(Ics); document.add(con004);}
                  else {document.add(Quad); document.add(con004);}
                if(st.getCompetenze_coerenza(k)==5) {document.add(Ics); document.add(con005);}
                  else {document.add(Quad); document.add(con005);}
                document.add(Chunk.NEWLINE); document.add(Chunk.NEWLINE);
                //document.add(new Paragraph("Competenze - coerenza/aderenza: " + CompCoerList[st.getCompetenze_coerenza(k)]));

                Titolo="Competenze: esposizione";
                Chunk comp0001=new Chunk(Titolo, new Font(Font.FontFamily.HELVETICA, 12, Font.BOLD));
                document.add(comp0001); document.add(Chunk.NEWLINE);
                s1=" confusa   ";
                s2=" imprecisa   ";
                s3=" semplice   ";
                s4=" abbastanza chiara   ";
                s5=" chiara   ";
                Chunk con0001 = new Chunk(s1);
                Chunk con0002 = new Chunk(s2);
                Chunk con0003 = new Chunk(s3);
                Chunk con0004 = new Chunk(s4);
                Chunk con0005 = new Chunk(s5);
                Chunk con0006 = new Chunk(s6);
                if(st.getCompetenze_esposizione(k)==1) {document.add(Ics); document.add(con0001);}
                  else {document.add(Quad); document.add(con0001);}
                if(st.getCompetenze_esposizione(k)==2) {document.add(Ics); document.add(con0002);}
                  else {document.add(Quad); document.add(con0002);}
                if(st.getCompetenze_esposizione(k)==3) {document.add(Ics); document.add(con0003);}
                  else {document.add(Quad); document.add(con0003);}
                if(st.getCompetenze_esposizione(k)==4) {document.add(Ics); document.add(con0004);}
                  else {document.add(Quad); document.add(con0004);}
                if(st.getCompetenze_esposizione(k)==5) {document.add(Ics); document.add(con0005);}
                  else {document.add(Quad); document.add(con0005);}
                document.add(Chunk.NEWLINE); document.add(Chunk.NEWLINE);
                //document.add(new Paragraph("Competenze - esposizione: " + CompEspList[st.getCompetenze_esposizione(k)]));

                Titolo="Competenze: linguaggio specifico";
                Chunk comp00001=new Chunk(Titolo, new Font(Font.FontFamily.HELVETICA, 12, Font.BOLD));
                document.add(comp00001); document.add(Chunk.NEWLINE);
                s1=" improprio   ";
                s2=" impreciso   ";
                s3=" elementare   ";
                s4=" abbastanza appropriato   ";
                s5=" appropriato   ";
                Chunk con00001 = new Chunk(s1);
                Chunk con00002 = new Chunk(s2);
                Chunk con00003 = new Chunk(s3);
                Chunk con00004 = new Chunk(s4);
                Chunk con00005 = new Chunk(s5);
                Chunk con00006 = new Chunk(s6);
                if(st.getCompetenze_linguaggio_specifico(k)==1) {document.add(Ics); document.add(con00001);}
                  else {document.add(Quad); document.add(con00001);}
                if(st.getCompetenze_linguaggio_specifico(k)==2) {document.add(Ics); document.add(con00002);}
                  else {document.add(Quad); document.add(con00002);}
                if(st.getCompetenze_linguaggio_specifico(k)==3) {document.add(Ics); document.add(con00003);}
                  else {document.add(Quad); document.add(con00003);}
                if(st.getCompetenze_linguaggio_specifico(k)==4) {document.add(Ics); document.add(con00004);}
                  else {document.add(Quad); document.add(con00004);}
                if(st.getCompetenze_linguaggio_specifico(k)==5) {document.add(Ics); document.add(con00005);}
                  else {document.add(Quad); document.add(con00005);}
                document.add(Chunk.NEWLINE); document.add(Chunk.NEWLINE);
                //document.add(new Paragraph("Competenze - linguaggio specifico: " + CompLingList[st.getCompetenze_linguaggio_specifico(k)]));

                Titolo="Capacità: analisi ed applicazione";
                Chunk cap0=new Chunk(Titolo, new Font(Font.FontFamily.HELVETICA, 12, Font.BOLD));
                document.add(cap0); document.add(Chunk.NEWLINE);
                s1=" confusa   ";
                s2=" occasionale   ";
                s3=" parziale   ";
                s4=" generale   ";
                s5=" globale   ";
                Chunk cap1 = new Chunk(s1);
                Chunk cap2 = new Chunk(s2);
                Chunk cap3 = new Chunk(s3);
                Chunk cap4 = new Chunk(s4);
                Chunk cap5 = new Chunk(s5);
                Chunk cap6 = new Chunk(s6);
                if(st.getCapacita_analisi_esposizione(k)==1) {document.add(Ics); document.add(cap1);}
                  else {document.add(Quad); document.add(cap1);}
                if(st.getCapacita_analisi_esposizione(k)==2) {document.add(Ics); document.add(cap2);}
                  else {document.add(Quad); document.add(cap2);}
                if(st.getCapacita_analisi_esposizione(k)==3) {document.add(Ics); document.add(cap3);}
                  else {document.add(Quad); document.add(cap3);}
                if(st.getCapacita_analisi_esposizione(k)==4) {document.add(Ics); document.add(cap4);}
                  else {document.add(Quad); document.add(cap4);}
                if(st.getCapacita_analisi_esposizione(k)==5) {document.add(Ics); document.add(cap5);}
                  else {document.add(Quad); document.add(cap5);}
                document.add(Chunk.NEWLINE); document.add(Chunk.NEWLINE);
                //document.add(new Paragraph("Capacità - analisi ed applicazione: " + CapAnAppl[st.getCapacita_analisi_esposizione(k)]));

                Titolo="Capacità: autonomia";
                Chunk cap00=new Chunk(Titolo, new Font(Font.FontFamily.HELVETICA, 12, Font.BOLD));
                document.add(cap00); document.add(Chunk.NEWLINE);
                s1=" manca di autonomia   ";
                s2=" poca autonomia   ";
                s3=" spunti di autonomia   ";
                s4=" globale autonomia   ";
                Chunk cap01 = new Chunk(s1);
                Chunk cap02 = new Chunk(s2);
                Chunk cap03 = new Chunk(s3);
                Chunk cap04 = new Chunk(s4);
                if(st.getCapacita_autonomia(k)==1) {document.add(Ics); document.add(cap01);}
                  else {document.add(Quad); document.add(cap01);}
                if(st.getCapacita_autonomia(k)==2) {document.add(Ics); document.add(cap02);}
                  else {document.add(Quad); document.add(cap02);}
                if(st.getCapacita_autonomia(k)==3) {document.add(Ics); document.add(cap03);}
                  else {document.add(Quad); document.add(cap03);}
                if(st.getCapacita_autonomia(k)==4) {document.add(Ics); document.add(cap04);}
                  else {document.add(Quad); document.add(cap04);}
                document.add(Chunk.NEWLINE); document.add(Chunk.NEWLINE);
                //document.add(new Paragraph("Capacità - autonomia: " + CapAut[st.getCapacita_autonomia(k)]));

                Titolo="Valutazione complessiva della prova:";
                Chunk cap000=new Chunk(Titolo, new Font(Font.FontFamily.HELVETICA, 12, Font.BOLD));
                document.add(cap000); document.add(Chunk.NEWLINE);
                s1=" esito positivo   ";
                s2=" esito negativo   ";
                s3="verifica non effettuata per assenza";
                Chunk cap001 = new Chunk(s1);
                Chunk cap002 = new Chunk(s2);
                Chunk cap003 = new Chunk(s3);
                if(st.getValutazione_prova(k)==1) {document.add(Ics); document.add(cap001);}
                  else {document.add(Quad); document.add(cap001);}
                if(st.getValutazione_prova(k)==2) {document.add(Ics); document.add(cap002);}
                  else {document.add(Quad); document.add(cap002);}
                if(st.getValutazione_prova(k)==3) {document.add(Ics); document.add(cap003);}
                  else {document.add(Quad); document.add(cap003);}
                document.add(Chunk.NEWLINE); document.add(Chunk.NEWLINE);
                //document.add(new Paragraph("Valutazione compessiva della prova: " + ValProva[st.getValutazione_prova(k)]));

                //document.add(new Paragraph(" "));
                //Far leggere la dadta dal form...
                String data = jTextField6.getText();   //"05.03.2010";
                document.add(new Paragraph("Foligno, " + data + "                                     Il docente"));
                //Far leggere il NomeDocente dal form...
                String NomeDocente = jTextField7.getText();  //"Piluso Gianluigi";
                document.add(new Paragraph("                                                               " + NomeDocente));
                document.newPage();
            }
        } catch (DocumentException de) {
            System.err.println(de.getMessage());
        } catch (IOException ioe) {
            System.err.println(ioe.getMessage());
        }
        document.close();
    }


    public void StampaFileExcel() {
        AggiornaComboBox();
        ww.openScriviFile();
        ww.writeScriviFile("Nome"+"|");
        ww.writeScriviFile("Classe"+"|");
        ww.writeScriviFile("Conoscenze"+"|");
        ww.writeScriviFile("CompCompr"+"|");
        ww.writeScriviFile("CompCoer"+"|");
        ww.writeScriviFile("CompEsp"+"|");
        ww.writeScriviFile("CompLing"+"|");
        ww.writeScriviFile("CapAnal"+"|");
        ww.writeScriviFile("CapAut"+"|");
        ww.writeScriviFile("ValEsito"+"|");
        ww.writeScriviFile("TipProva"+"|");
        ww.writeScriviFile("Voto"+"|");
        ww.writeScriviFile("Argomenti"+"\r\n");
        for(int k=0; k< totaleAlunni; k++) {
            ww.writeScriviFile(st.getNome(k)+"|");
            ww.writeScriviFile(st.getClasse(k)+"|");            
            ww.writeScriviFile(ConoscenzeList[st.getConoscenze(k)]+"|");
            ww.writeScriviFile(CompComprList[st.getCompetenze_comprensione(k)]+"|");
            ww.writeScriviFile(CompCoerList[st.getCompetenze_coerenza(k)]+"|");
            ww.writeScriviFile(CompEspList[st.getCompetenze_esposizione(k)]+"|");
            ww.writeScriviFile(CompLingList[st.getCompetenze_linguaggio_specifico(k)]+"|");
            ww.writeScriviFile(CapAnAppl[st.getCapacita_analisi_esposizione(k)]+"|");
            ww.writeScriviFile(CapAut[st.getCapacita_autonomia(k)]+"|");
            ww.writeScriviFile(ValProva[st.getValutazione_prova(k)]+"|");
            ww.writeScriviFile(TipologiaProva[st.getTipologia_verifica(k)]+"|");
            ww.writeScriviFile(" "+Voto[st.getVoto(k)]+"|");
            ww.writeScriviFile(st.getArgomenti(k)+"\r\n");
        }
        ww.closeScriviFile();
    }

    public void Decodifica(int k) {
        String riga="";
        int j=0;
        int t=0;
        riga = recupero.getRiga(k);
        
        j = riga.indexOf('|');
        String Nome = riga.substring(0, j);
        st.setNome(k, Nome);

        t=j+1;
        riga=riga.substring(t, riga.length());
        System.out.println("+++"+riga);
        j = riga.indexOf('|');        
        String Classe = riga.substring(0, j);
        st.setClasse(k, Classe);

        t=j+1;
        riga=riga.substring(t, riga.length());
        j = riga.indexOf('|');
        int xCL = Integer.parseInt(riga.substring(0, j));

        t=j+1;
        riga=riga.substring(t, riga.length());
        j = riga.indexOf('|');
        int xCCL = Integer.parseInt(riga.substring(0, j));

        t=j+1;
        riga=riga.substring(t, riga.length());
        j = riga.indexOf('|');
        int xCCAL = Integer.parseInt(riga.substring(0, j));

        t=j+1;
        riga=riga.substring(t, riga.length());
        j = riga.indexOf('|');
        int xCEL = Integer.parseInt(riga.substring(0, j));

        t=j+1;
        riga=riga.substring(t, riga.length());
        j = riga.indexOf('|');
        int xCLSL = Integer.parseInt(riga.substring(0, j));

        t=j+1;
        riga=riga.substring(t, riga.length());
        j = riga.indexOf('|');
        int xCAEL = Integer.parseInt(riga.substring(0, j));

        t=j+1;
        riga=riga.substring(t, riga.length());
        j = riga.indexOf('|');
        int xCAL = Integer.parseInt(riga.substring(0, j));

        t=j+1;
        riga=riga.substring(t, riga.length());
        j = riga.indexOf('|');
        int xVPL = Integer.parseInt(riga.substring(0, j));

        t=j+1;
        riga=riga.substring(t, riga.length());
        j = riga.indexOf('|');
        int xTVL = Integer.parseInt(riga.substring(0, j));

        t=j+1;
        riga=riga.substring(t, riga.length());
        j = riga.indexOf('|');
        int xVL = Integer.parseInt(riga.substring(0, j));

        t=j+1;
        riga=riga.substring(t, riga.length());
        j = riga.indexOf('|');  
        String Arg = riga.substring(0, riga.length());

        ScriviStrutturaDati(k, xCL, xCCL, xCCAL, xCEL, xCLSL, xCAEL, xCAL, xVPL,
                xTVL, xVL, Arg);
    }

    public void toggleComponenti(boolean OraleFlag) {
        //Sono invisibili fino a che non si seleziona la prova orale
        jLabel12.setVisible(OraleFlag);
        jTextArea1.setVisible(OraleFlag);
        jLabel13.setVisible(OraleFlag);
        jComboBox10.setVisible(OraleFlag);
    }

    //Memorizza nella struttura dati
    public void ScriviStrutturaDati(int k,int xCL, int xCCL, int xCCAL,
            int xCEL, int xCLSL, int xCAEL, int xCAL, int xVPL, int xTVL,
            int xVL, String Arg) {
        st.setNome(k,r.getNomeAlunni(k));
        st.setClasse(k, r.getClasse(k));
        st.setConoscenze(k, xCL);
        st.setCompetenze_comprensione(k, xCCL);
        st.setCompetenze_coerenza(k, xCCAL);
        st.setCompetenze_esposizione(k, xCEL);
        st.setCompetenze_linguaggio_specifico(k, xCLSL);
        st.setCapacita_analisi_esposizione(k, xCAEL);
        st.setCapacita_autonomia(k, xCAL);
        st.setValutazione_prova(k, xVPL);
        st.setTipologia_verifica(k, xTVL);
        st.setVoto(k, xVL);
        st.setArgomenti(k, Arg);
    }

    public void Stampa(int nAlunno, int x1, int x2, int x3, int x4, int x5,
            int x6, int x7, int x8, int x9, int x10, String Arg) {
        //System.out.println("*** "+nAlunno+" "+r.getNomeAlunni(nAlunno)+" - "+ConoscenzeList[x1]+" - "+CompComprList[x2]+" ***");
        int k=nAlunno;
        System.out.println("*** "+k+" "+st.getNome(k)+" - "+
                st.getConoscenze(k)+" - "+
                st.getCompetenze_comprensione(k)+" - "+
                st.getCompetenze_coerenza(k)+" - "+
                st.getCompetenze_esposizione(k)+" - "+
                st.getCompetenze_linguaggio_specifico(k)+" - "+
                st.getCapacita_analisi_esposizione(k)+" - "+
                st.getCapacita_autonomia(k)+" - "+
                st.getValutazione_prova(k)+" - "+
                st.getTipologia_verifica(k)+" - "+
                st.getVoto(k)+" - "+
                st.getArgomenti(k)+
                " ***");
    }

    public void AggiornaForm(int nAlunno) {
        jTextField1.setText(st.getNome(nAlunno));
        jTextField2.setText(st.getClasse(nAlunno));
        jTextArea1.setText(st.getArgomenti(nAlunno));
        int xCL=st.getConoscenze(nAlunno);
        int xCCL=st.getCompetenze_comprensione(nAlunno);
        int xCCAL=st.getCompetenze_coerenza(nAlunno);
        int xCEL=st.getCompetenze_esposizione(nAlunno);
        int xCLSL=st.getCompetenze_linguaggio_specifico(nAlunno);
        int xCAEL=st.getCapacita_analisi_esposizione(nAlunno);
        int xCAL=st.getCapacita_autonomia(nAlunno);
        int xVPL=st.getValutazione_prova(nAlunno);
        int xTVL=st.getTipologia_verifica(nAlunno);
        int xVL=st.getVoto(nAlunno);
        String Arg=st.getArgomenti(nAlunno);
        jComboBox1.setSelectedIndex(xCL);
        jComboBox2.setSelectedIndex(xCCL);
        jComboBox3.setSelectedIndex(xCCAL);
        jComboBox4.setSelectedIndex(xCEL);
        jComboBox5.setSelectedIndex(xCLSL);
        jComboBox6.setSelectedIndex(xCAEL);
        jComboBox7.setSelectedIndex(xCAL);
        jComboBox8.setSelectedIndex(xVPL);
        jComboBox9.setSelectedIndex(xTVL);
        jComboBox10.setSelectedIndex(xVL);
        jTextArea1.setText(Arg);
        System.out.println("> Aggiorna Form <");
        //Stampa(nAlunno,xCL,xCCL,xCCAL,xCEL,xCLSL,xCAEL,xCAL,xVPL,xTVL,xVL,Arg);
    }

    public void AggiornaComboBox() {
        int xCL=jComboBox1.getSelectedIndex();
        int xCCL=jComboBox2.getSelectedIndex();
        int xCCAL=jComboBox3.getSelectedIndex();
        int xCEL=jComboBox4.getSelectedIndex();
        int xCLSL=jComboBox5.getSelectedIndex();
        int xCAEL=jComboBox6.getSelectedIndex();
        int xCAL=jComboBox7.getSelectedIndex();
        int xVPL=jComboBox8.getSelectedIndex();
        int xTVL=jComboBox9.getSelectedIndex();
        int xVL=jComboBox10.getSelectedIndex();
        String Arg=jTextArea1.getText();
        ScriviStrutturaDati(nAlunno,xCL,xCCL,xCCAL,xCEL,xCLSL,xCAEL,xCAL,xVPL,xTVL,xVL,Arg);
        //Stampa(nAlunno,xCL,xCCL,xCCAL,xCEL,xCLSL,xCAEL,xCAL,xVPL,xTVL,xVL,Arg);
    }

    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        B_Inizio = new javax.swing.JButton();
        B_Decrementa = new javax.swing.JButton();
        B_Incrementa = new javax.swing.JButton();
        B_Fine = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jTextField2 = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jComboBox1 = new javax.swing.JComboBox();
        jLabel4 = new javax.swing.JLabel();
        jComboBox2 = new javax.swing.JComboBox();
        B_Salva = new javax.swing.JButton();
        jComboBox3 = new javax.swing.JComboBox();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jComboBox4 = new javax.swing.JComboBox();
        jLabel7 = new javax.swing.JLabel();
        jComboBox5 = new javax.swing.JComboBox();
        jLabel8 = new javax.swing.JLabel();
        jComboBox6 = new javax.swing.JComboBox();
        jLabel9 = new javax.swing.JLabel();
        jComboBox7 = new javax.swing.JComboBox();
        jLabel10 = new javax.swing.JLabel();
        jComboBox8 = new javax.swing.JComboBox();
        jLabel11 = new javax.swing.JLabel();
        jComboBox9 = new javax.swing.JComboBox();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jComboBox10 = new javax.swing.JComboBox();
        jTextField3 = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jTextField4 = new javax.swing.JTextField();
        jButton2 = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jLabel14 = new javax.swing.JLabel();
        jTextField5 = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        jTextField6 = new javax.swing.JTextField();
        jLabel16 = new javax.swing.JLabel();
        jTextField7 = new javax.swing.JTextField();
        B_EsportaExcel = new javax.swing.JButton();
        B_EsportaPDF = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Recupero - GP");
        setResizable(false);

        jLabel1.setText("Alunno");

        B_Inizio.setText("<<");
        B_Inizio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_InizioActionPerformed(evt);
            }
        });

        B_Decrementa.setText("<");
        B_Decrementa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_DecrementaActionPerformed(evt);
            }
        });

        B_Incrementa.setText(">");
        B_Incrementa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_IncrementaActionPerformed(evt);
            }
        });

        B_Fine.setText(">>");
        B_Fine.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_FineActionPerformed(evt);
            }
        });

        jLabel2.setText("Classe");

        jLabel3.setText("1 - Conoscenze");

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "--- Selezionare ---", "nulle", "gravemente lacunose", "limitate/parziali", "essenziali", "in parte complete", "complete" }));
        jComboBox1.setPreferredSize(new java.awt.Dimension(180, 22));
        jComboBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox1ActionPerformed(evt);
            }
        });

        jLabel4.setText("2 - Competenze: comprensione");

        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "--- Selezionare ---", "limitata", "parziale", "essenziale", "discreta", "precisa" }));
        jComboBox2.setPreferredSize(new java.awt.Dimension(180, 22));
        jComboBox2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox2ActionPerformed(evt);
            }
        });

        B_Salva.setText("Salva File");
        B_Salva.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_SalvaActionPerformed(evt);
            }
        });

        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "--- Selezionare ---", "occasionale", "parziale", "generale", "globale", "piena" }));
        jComboBox3.setPreferredSize(new java.awt.Dimension(180, 22));
        jComboBox3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox3ActionPerformed(evt);
            }
        });

        jLabel5.setText("3 - Competenze: coerenza - aderenza");

        jLabel6.setText("4 - Competenze: esposizione");

        jComboBox4.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "--- Selezionare ---", "confusa", "imprecisa", "semplice", "abbastanza chiara", "chiara" }));
        jComboBox4.setPreferredSize(new java.awt.Dimension(180, 22));
        jComboBox4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox4ActionPerformed(evt);
            }
        });

        jLabel7.setText("5 - Competenze: linguaggio specifico");

        jComboBox5.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "--- Selezionare ---", "improprio", "impreciso", "elementare", "abbastanza appropriato", "appropriato" }));
        jComboBox5.setPreferredSize(new java.awt.Dimension(180, 22));
        jComboBox5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox5ActionPerformed(evt);
            }
        });

        jLabel8.setText("6 - Capacità: analisi ed applicazione");

        jComboBox6.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "--- Selezionare ---", "confusa", "occasionale", "parziale", "generale", "globale" }));
        jComboBox6.setPreferredSize(new java.awt.Dimension(180, 22));
        jComboBox6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox6ActionPerformed(evt);
            }
        });

        jLabel9.setText("7 - Capacità: autonomia");

        jComboBox7.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "--- Selezionare ---", "manca di autonomia", "poca autonomia", "spunti di autonomia", "globale autonomia" }));
        jComboBox7.setPreferredSize(new java.awt.Dimension(180, 22));
        jComboBox7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox7ActionPerformed(evt);
            }
        });

        jLabel10.setText("8 - Valutazione complessiva della prova");

        jComboBox8.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "--- Selezionare ---", "esito positivo", "esito negativo", "verifica non effettuata per assenza" }));
        jComboBox8.setPreferredSize(new java.awt.Dimension(180, 22));
        jComboBox8.setVerifyInputWhenFocusTarget(false);
        jComboBox8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox8ActionPerformed(evt);
            }
        });

        jLabel11.setText("0 - Tipologia della Prova");

        jComboBox9.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "--- Selezionare ---", "(*) Test", "(*) Quesiti", "(*) Risposte aperte", "(*) Questionario", "(*) Altro", "Orale" }));
        jComboBox9.setPreferredSize(new java.awt.Dimension(180, 22));
        jComboBox9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox9ActionPerformed(evt);
            }
        });

        jTextArea1.setColumns(20);
        jTextArea1.setLineWrap(true);
        jTextArea1.setRows(5);
        jScrollPane1.setViewportView(jTextArea1);

        jLabel12.setText("Argomenti e contenuti");

        jLabel13.setText("Voto");

        jComboBox10.setMaximumRowCount(11);
        jComboBox10.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "--- Selezionare ---", "1/10", "2/10", "3/10", "4/10", "5/10", "6/10", "7/10", "8/10", "9/10", "10/10" }));
        jComboBox10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox10ActionPerformed(evt);
            }
        });

        jTextField3.setText("Lista.txt");

        jButton1.setText("Leggi Lista Iniziale");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jTextField4.setText("Recupero.dat");

        jButton2.setText("Leggi Recupero");

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder("Dati stesura documento"));

        jLabel14.setText("Disciplina");

        jTextField5.setText("Fisica e Lab.");

        jLabel15.setText("Data");

        jTextField6.setText("05.03.2010");

        jLabel16.setText("Nome Docente");

        jTextField7.setText("Gianluigi Piluso");

        org.jdesktop.layout.GroupLayout jPanel1Layout = new org.jdesktop.layout.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(org.jdesktop.layout.GroupLayout.TRAILING, jTextField7, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 154, Short.MAX_VALUE)
                    .add(org.jdesktop.layout.GroupLayout.TRAILING, jTextField6, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 154, Short.MAX_VALUE)
                    .add(org.jdesktop.layout.GroupLayout.TRAILING, jTextField5, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 154, Short.MAX_VALUE)
                    .add(jLabel16)
                    .add(jLabel15)
                    .add(jLabel14))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel1Layout.createSequentialGroup()
                .add(jLabel14)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jTextField5, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                .add(jLabel15)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jTextField6, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                .add(jLabel16)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jTextField7, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        B_EsportaExcel.setText("Esporta CSV");
        B_EsportaExcel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_EsportaExcelActionPerformed(evt);
            }
        });

        B_EsportaPDF.setText("Esporta PDF");
        B_EsportaPDF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_EsportaPDFActionPerformed(evt);
            }
        });

        org.jdesktop.layout.GroupLayout layout = new org.jdesktop.layout.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(layout.createSequentialGroup()
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING, false)
                        .add(layout.createSequentialGroup()
                            .addContainerGap()
                            .add(jComboBox1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 180, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                        .add(layout.createSequentialGroup()
                            .addContainerGap()
                            .add(jComboBox3, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 180, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                        .add(layout.createSequentialGroup()
                            .add(10, 10, 10)
                            .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                                .add(jComboBox2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 180, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                .add(jLabel11)
                                .add(jLabel4)
                                .add(jLabel5, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                        .add(layout.createSequentialGroup()
                            .addContainerGap()
                            .add(jComboBox9, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 180, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                    .add(layout.createSequentialGroup()
                        .addContainerGap()
                        .add(jLabel3)))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jComboBox10, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 180, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(layout.createSequentialGroup()
                        .add(2, 2, 2)
                        .add(jLabel13))
                    .add(jScrollPane1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 233, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
            .add(layout.createSequentialGroup()
                .addContainerGap()
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                    .add(org.jdesktop.layout.GroupLayout.LEADING, layout.createSequentialGroup()
                        .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING, false)
                            .add(org.jdesktop.layout.GroupLayout.LEADING, jLabel1)
                            .add(org.jdesktop.layout.GroupLayout.LEADING, jTextField1)
                            .add(org.jdesktop.layout.GroupLayout.LEADING, layout.createSequentialGroup()
                                .add(B_Inizio)
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                .add(B_Decrementa)
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                .add(B_Incrementa)
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                .add(B_Fine)))
                        .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(layout.createSequentialGroup()
                                .add(26, 26, 26)
                                .add(jLabel2))
                            .add(layout.createSequentialGroup()
                                .add(18, 18, 18)
                                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                                    .add(jTextField2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 119, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                    .add(jLabel12)))))
                    .add(layout.createSequentialGroup()
                        .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(jTextField3, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 219, Short.MAX_VALUE)
                            .add(org.jdesktop.layout.GroupLayout.TRAILING, jTextField4, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 219, Short.MAX_VALUE))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                        .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING, false)
                            .add(jButton1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .add(jButton2, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 208, Short.MAX_VALUE))))
                .add(244, 244, 244))
            .add(layout.createSequentialGroup()
                .addContainerGap()
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jLabel6)
                    .add(jLabel7)
                    .add(jLabel8, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 239, Short.MAX_VALUE)
                    .add(jLabel9)
                    .add(jLabel10, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 239, Short.MAX_VALUE)
                    .add(jComboBox5, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 180, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(jComboBox4, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 180, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(jComboBox7, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 180, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(jComboBox6, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 180, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(jComboBox8, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 180, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .add(248, 248, 248))
            .add(layout.createSequentialGroup()
                .add(10, 10, 10)
                .add(B_Salva)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                .add(B_EsportaExcel)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                .add(B_EsportaPDF)
                .add(402, 402, 402))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(layout.createSequentialGroup()
                .addContainerGap()
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(jTextField3, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(jButton1))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(jTextField4, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(jButton2))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(layout.createSequentialGroup()
                        .add(jLabel1)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jTextField1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(B_Inizio)
                            .add(B_Decrementa)
                            .add(B_Incrementa)
                            .add(B_Fine)))
                    .add(layout.createSequentialGroup()
                        .add(jLabel2)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jTextField2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                .add(7, 7, 7)
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(jLabel11)
                    .add(jLabel12))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                    .add(layout.createSequentialGroup()
                        .add(jComboBox9, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 22, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                        .add(jLabel3)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jComboBox1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 22, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                        .add(jLabel4)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jComboBox2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 22, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jLabel5)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                        .add(jComboBox3, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 22, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                    .add(jScrollPane1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 169, Short.MAX_VALUE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                    .add(layout.createSequentialGroup()
                        .add(jLabel6)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jComboBox4, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 22, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                    .add(layout.createSequentialGroup()
                        .add(jLabel13)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jComboBox10, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 22, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jLabel7)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(layout.createSequentialGroup()
                        .add(jComboBox5, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 22, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jLabel8)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                        .add(jComboBox6, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 22, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jLabel9)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jComboBox7, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 22, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jLabel10)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jComboBox8, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 22, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .add(11, 11, 11)
                        .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(B_Salva)
                            .add(B_EsportaExcel)
                            .add(B_EsportaPDF)))
                    .add(jPanel1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .add(105, 105, 105))
        );

        B_Inizio.getAccessibleContext().setAccessibleName("Inizio");
        B_Decrementa.getAccessibleContext().setAccessibleName("Decrementa");
        B_Incrementa.getAccessibleContext().setAccessibleName("Incrementa");
        B_Fine.getAccessibleContext().setAccessibleName("Button_Fine");

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jComboBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox1ActionPerformed
        AggiornaComboBox();
    }//GEN-LAST:event_jComboBox1ActionPerformed

    private void jComboBox2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox2ActionPerformed
        AggiornaComboBox();
    }//GEN-LAST:event_jComboBox2ActionPerformed

    private void B_InizioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_B_InizioActionPerformed
        Salva();
        nAlunno=0;
        AggiornaForm(nAlunno);
    }//GEN-LAST:event_B_InizioActionPerformed

    private void B_FineActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_B_FineActionPerformed
        Salva();
        nAlunno=totaleAlunni-1;
        AggiornaForm(nAlunno);
    }//GEN-LAST:event_B_FineActionPerformed

    private void B_DecrementaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_B_DecrementaActionPerformed
        Salva();
        if(nAlunno>0) {
            nAlunno=nAlunno-1;
            AggiornaForm(nAlunno);
        }        
    }//GEN-LAST:event_B_DecrementaActionPerformed

    private void B_IncrementaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_B_IncrementaActionPerformed
        Salva();
        if(nAlunno<(totaleAlunni-1)) {
            nAlunno=nAlunno+1;
            AggiornaForm(nAlunno);
        }
    }//GEN-LAST:event_B_IncrementaActionPerformed

    private void jComboBox3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox3ActionPerformed
        AggiornaComboBox();
    }//GEN-LAST:event_jComboBox3ActionPerformed

    private void jComboBox4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox4ActionPerformed
        AggiornaComboBox();
    }//GEN-LAST:event_jComboBox4ActionPerformed

    private void jComboBox5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox5ActionPerformed
        AggiornaComboBox();
    }//GEN-LAST:event_jComboBox5ActionPerformed

    private void jComboBox6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox6ActionPerformed
        AggiornaComboBox();
    }//GEN-LAST:event_jComboBox6ActionPerformed

    private void jComboBox7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox7ActionPerformed
        AggiornaComboBox();
    }//GEN-LAST:event_jComboBox7ActionPerformed

    private void jComboBox8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox8ActionPerformed
        AggiornaComboBox();
    }//GEN-LAST:event_jComboBox8ActionPerformed

    private void jComboBox9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox9ActionPerformed
        boolean OraleFlag=false;
        if(jComboBox9.getSelectedIndex()==6) {
            OraleFlag=true;
            toggleComponenti(OraleFlag);
        }
        else {
            OraleFlag=false;
            //jTextArea1.setText("");
            toggleComponenti(OraleFlag);
        }

        AggiornaComboBox();
    }//GEN-LAST:event_jComboBox9ActionPerformed

    private void jComboBox10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox10ActionPerformed
        AggiornaComboBox();
    }//GEN-LAST:event_jComboBox10ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        //Legge il file complesso con nomi, classe e varie selezioni

    }//GEN-LAST:event_jButton1ActionPerformed

    private void B_SalvaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_B_SalvaActionPerformed
        Salva();                     
    }//GEN-LAST:event_B_SalvaActionPerformed

    private void B_EsportaPDFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_B_EsportaPDFActionPerformed
        StampaPdf();
    }//GEN-LAST:event_B_EsportaPDFActionPerformed

    private void B_EsportaExcelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_B_EsportaExcelActionPerformed
        StampaFileExcel();
    }//GEN-LAST:event_B_EsportaExcelActionPerformed

    public void Salva() {
        AggiornaComboBox();
        w.openScriviFile();
        for(int k=0; k< totaleAlunni; k++) {
            w.writeScriviFile(st.getNome(k)+"|");
            w.writeScriviFile(st.getClasse(k)+"|");
            w.writeScriviFile(String.valueOf(st.getConoscenze(k)).toString()+"|");
            w.writeScriviFile(String.valueOf(st.getCompetenze_comprensione(k)).toString()+"|");
            w.writeScriviFile(String.valueOf(st.getCompetenze_coerenza(k)).toString()+"|");
            w.writeScriviFile(String.valueOf(st.getCompetenze_esposizione(k)).toString()+"|");
            w.writeScriviFile(String.valueOf(st.getCompetenze_linguaggio_specifico(k)).toString()+"|");
            w.writeScriviFile(String.valueOf(st.getCapacita_analisi_esposizione(k)).toString()+"|");
            w.writeScriviFile(String.valueOf(st.getCapacita_autonomia(k)).toString()+"|");
            w.writeScriviFile(String.valueOf(st.getValutazione_prova(k)).toString()+"|");
            w.writeScriviFile(String.valueOf(st.getTipologia_verifica(k)).toString()+"|");
            w.writeScriviFile(String.valueOf(st.getVoto(k)).toString()+"|");
            w.writeScriviFile(st.getArgomenti(k)+"\r\n");
        }
        w.closeScriviFile();
    }

    /**
    * @param args the command line arguments
    */
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                //new NewJFrame().setVisible(true);
                NewJFrame frame = new NewJFrame();
                frame.setSize(500,720);
                frame.setVisible(true);
                Dimension screenSize =Toolkit.getDefaultToolkit().getScreenSize();
                Dimension frameSize = frame.getSize();
                frame.setLocation((screenSize.width - frameSize.width) / 2, (screenSize.height - frameSize.height) / 2);                
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton B_Decrementa;
    private javax.swing.JButton B_EsportaExcel;
    private javax.swing.JButton B_EsportaPDF;
    private javax.swing.JButton B_Fine;
    private javax.swing.JButton B_Incrementa;
    private javax.swing.JButton B_Inizio;
    private javax.swing.JButton B_Salva;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JComboBox jComboBox1;
    private javax.swing.JComboBox jComboBox10;
    private javax.swing.JComboBox jComboBox2;
    private javax.swing.JComboBox jComboBox3;
    private javax.swing.JComboBox jComboBox4;
    private javax.swing.JComboBox jComboBox5;
    private javax.swing.JComboBox jComboBox6;
    private javax.swing.JComboBox jComboBox7;
    private javax.swing.JComboBox jComboBox8;
    private javax.swing.JComboBox jComboBox9;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JTextField jTextField5;
    private javax.swing.JTextField jTextField6;
    private javax.swing.JTextField jTextField7;
    // End of variables declaration//GEN-END:variables
}
