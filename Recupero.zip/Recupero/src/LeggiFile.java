/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Gianluigi
 */
import java.io.*;

// Scriverlo via Scanner è più semplice

public class LeggiFile {
    private String strLine;
    private FileInputStream fstream;
    private DataInputStream in;
    private BufferedReader br;

    public void openLeggiFile() {
        try {
            //InputStreamReader reader = new InputStreamReader(System.in);
            //BufferedReader myInput = new BufferedReader(reader);
            //String str = new String();
            //System.out.println("Inserisci il nome del file da leggere: ");
            //str = myInput.readLine();

            fstream = new FileInputStream("Dati.txt");
            in = new DataInputStream(fstream);
            br = new BufferedReader(new InputStreamReader(in));
        } catch (Exception e) {
            System.err.println("Errore: " + e.getMessage());
        }
    }

    public void readLeggiFile() throws IOException {
        while ((strLine = br.readLine()) != null) {
            System.out.println(strLine);
        }
    }

    public void closeLeggiFile() throws IOException {
        in.close();
    }
}

/*    public void Leggi() {
        try {
            InputStreamReader reader = new InputStreamReader(System.in);
            BufferedReader myInput = new BufferedReader(reader);
            //String str = new String();
            //System.out.println("Inserisci il nome del file da leggere: ");
            //str = myInput.readLine();

            FileInputStream fstream = new FileInputStream("Dati.txt");
            DataInputStream in = new DataInputStream(fstream);
            BufferedReader br = new BufferedReader(new InputStreamReader(in));
            String strLine;
            while ((strLine = br.readLine()) != null) {
                System.out.println(strLine);
            }

            in.close();
        } catch (Exception e) {
            System.err.println("Errore: " + e.getMessage());
        }
    } */