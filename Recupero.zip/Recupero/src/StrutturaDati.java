/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Gianluigi
 */
public class StrutturaDati {
    private int numeroAlunni;
    private String[] Nome;
    private String[] Classe;
    private int[] Conoscenze;
    private int[] Competenze_comprensione;
    private int[] Competenze_coerenza;
    private int[] Competenze_esposizione;
    private int[] Competenze_linguaggio_spefico;
    private int[] Capacita_analisi_esposizione;
    private int[] Capacita_autonomia;
    private int[] Valutazione_prova;
    private int[] Tipologia_verifica;
    private int[] Voto;
    private String[] Argomenti;
    //private boolean[] OraleFlag;

    //Costruttore
    public StrutturaDati(int nAlunni) {
        setNumeroAlunni(nAlunni);
        Nome = new String[numeroAlunni];
        Classe = new String[numeroAlunni];
        Conoscenze = new int[numeroAlunni];
        Competenze_comprensione = new int[numeroAlunni];
        Competenze_coerenza = new int[numeroAlunni];
        Competenze_esposizione = new int[numeroAlunni];
        Competenze_linguaggio_spefico = new int[numeroAlunni];
        Capacita_analisi_esposizione = new int[numeroAlunni];
        Capacita_autonomia = new int[numeroAlunni];
        Valutazione_prova = new int[numeroAlunni];
        Tipologia_verifica = new int[numeroAlunni];
        Voto = new int[numeroAlunni];
        Argomenti = new String[numeroAlunni];
        //OraleFlag = new boolean[numeroAlunni];
    }

    public int getNumeroAlunni() {
        return numeroAlunni;
    }

    public void setNumeroAlunni(int nAlunni) {
        numeroAlunni=nAlunni;
    }

    public String getNome(int i){
        return Nome[i];
    }

    public void setNome(int i, String NomeAlunno) {
        Nome[i]=NomeAlunno;
    }

    public String getClasse(int i){
        return Classe[i];
    }

    public void setClasse(int i, String ClasseAlunno){
        Classe[i]=ClasseAlunno;
    }

    public int getConoscenze(int i){
        return Conoscenze[i];
    }

    public void setConoscenze(int i, int ConoscenzeAlunno){
        Conoscenze[i]=ConoscenzeAlunno;
    }

    public int getCompetenze_comprensione(int i){
        return Competenze_comprensione[i];
    }

    public void setCompetenze_comprensione(int i, int Competenze_comprensioneAlunno){
        Competenze_comprensione[i]=Competenze_comprensioneAlunno;
    }

    public int getCompetenze_coerenza(int i){
        return Competenze_coerenza[i];
    }

    public void setCompetenze_coerenza(int i, int Competenze_coerenzaAlunno){
        Competenze_coerenza[i]=Competenze_coerenzaAlunno;
    }

    public int getCompetenze_esposizione(int i){
        return Competenze_esposizione[i];
    }

    public void setCompetenze_esposizione(int i, int Competenze_esposizioneAlunno){
        Competenze_esposizione[i]=Competenze_esposizioneAlunno;
    }

    public int getCompetenze_linguaggio_specifico(int i){
        return Competenze_linguaggio_spefico[i];
    }

    public void setCompetenze_linguaggio_specifico(int i, int Competenze_linguaggio_specificoAlunno){
        Competenze_linguaggio_spefico[i]=Competenze_linguaggio_specificoAlunno;
    }

    public int getCapacita_analisi_esposizione(int i){
        return Capacita_analisi_esposizione[i];
    }

    public void setCapacita_analisi_esposizione(int i, int Capacita_analisi_esposizioneAlunno){
        Capacita_analisi_esposizione[i]=Capacita_analisi_esposizioneAlunno;
    }


    public int getCapacita_autonomia(int i){
        return Capacita_autonomia[i];
    }

    public void setCapacita_autonomia(int i, int Capacita_autonomiaAlunno){
        Capacita_autonomia[i]=Capacita_autonomiaAlunno;
    }


    public int getValutazione_prova(int i){
        return Valutazione_prova[i];
    }

    public void setValutazione_prova(int i, int Valutazione_provaAlunno){
        Valutazione_prova[i]=Valutazione_provaAlunno;
    }


    public int getTipologia_verifica(int i){
        return Tipologia_verifica[i];
    }

    public void setTipologia_verifica(int i, int Tipologia_verificaAlunno){
        Tipologia_verifica[i]=Tipologia_verificaAlunno;
    }

    public int getVoto(int i){
        return Voto[i];
    }

    public void setVoto(int i, int VotoAlunno){
        Voto[i]=VotoAlunno;
    }

    public String getArgomenti(int i){
        return Argomenti[i];
    }

    public void setArgomenti(int i, String Arg){
        Argomenti[i]=Arg;
    }
}
