/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Gianluigi
 */
import java.io.*;

public class ScriviFile {
    private FileWriter out;

    //String nomefile = "Recupero.dat";
    String nomefile="";

    public ScriviFile(String FileName) {
        nomefile=FileName;
    }

    public void openScriviFile() {
        try {
            out = new FileWriter(nomefile);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public void writeScriviFile(String cosa) {
        try {
            out.write(cosa);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public void closeScriviFile() {
        try {
            out.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
