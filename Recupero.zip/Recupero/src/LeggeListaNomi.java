/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Gianluigi
 */
import java.io.*;
import java.util.*;

public class LeggeListaNomi {
    private String s[]=new String[640];
    private String Classe[];
    private String NomeCognomeAlunno[];
    private Scanner x;
    private int NumeroAlunni=0;
    private String NomeFile;

    public String getNomeFile() {
        return NomeFile;
    }

    public void setNomeFile(String Nome_del_File) {
        NomeFile=Nome_del_File;
    }

    public void openListaNomi(){
        try{
            x=new Scanner(new File(NomeFile));
        }
        catch(Exception e){
            System.out.println("LeggeListaNomi.openListaNomi: Non ho trovato nessun File");
        }
    }

    public void readListaNomi(){
        int i=0;
        int n=0;
        while(x.hasNext()){
            //String Cognome =x.next();
            String Nome =x.nextLine();

            //System.out.print(Cognome+" ");
            System.out.println(Nome);
            s[i]=Nome;
            i=i+1;
        }
        NumeroAlunni=i;
    }

    public int getNumeroAlunni() {
        DividiCampi();
        return NumeroAlunni;
    }

    public String getRiga(int k) {
        return s[k];
    }

    // Ricordarsi che gli array variano da 0..n
    public String getNomeAlunni(int k) {
        //return s[k];
        return NomeCognomeAlunno[k];
    }

    public String getClasse(int k) {
        //return s[k];
        return Classe[k];
    }

    public void closeListaNomi(){
        x.close();
    }

    public void DividiCampi() {
        Classe = new String [NumeroAlunni];
        NomeCognomeAlunno=new String[NumeroAlunni];
        for(int i=0; i<NumeroAlunni; i++) {
            int k=s[i].indexOf(';');
            Classe[i]=s[i].substring(0,k);
            NomeCognomeAlunno[i]=s[i].substring(k+1,s[i].length());
        }
    }
}
