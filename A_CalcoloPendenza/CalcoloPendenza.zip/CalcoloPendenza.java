import java.applet.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class CalcoloPendenza extends Applet {
    //GridLayout GL = new GridLayout(7,2);
    Label L1 = new Label(" X1");
    TextField TF1 = new TextField("0");
    Label L2 = new Label(" Y1");
    TextField TF2 = new TextField("0");
    Label L3 = new Label(" X2");
    TextField TF3 = new TextField("1");
    Label L4 = new Label(" Y2");
    TextField TF4 = new TextField("1");
    Button B = new Button("Calcola Pendenza");
    Label L7 = new Label(" ");
    Label L5 = new Label(" Pendenza");
    TextField TF5 = new TextField(" ");
    Label L6 = new Label(" Pendenza %");
    TextField TF6 = new TextField(" ");

    public void init() {
        this.setLayout(null);
        this.setBackground(new Color(239,237,223));
        //this.setLayout(GL);
        this.L1.setForeground(Color.RED);
        this.L1.setBounds(5,5,80,20);
        this.add(L1);
        this.TF1.setForeground(Color.RED);
        this.TF1.setBounds(100,5,80,20);
        this.add(TF1);
        this.L2.setForeground(Color.RED);
        this.L2.setBounds(5,25,80,20);
        this.add(L2);
        this.TF2.setForeground(Color.RED);
        this.TF2.setBounds(100,25,80,20);
        this.add(TF2);
        this.L3.setForeground(Color.RED);
        this.L3.setBounds(5,45,80,20);
        this.add(L3);
        this.TF3.setForeground(Color.RED);
        this.TF3.setBounds(100,45,80,20);
        this.add(TF3);
        this.L4.setForeground(Color.RED);
        this.L4.setBounds(5,65,80,20);
        this.add(L4);
        this.TF4.setForeground(Color.RED);
        this.TF4.setBounds(100,65,80,20);
        this.add(TF4);
        this.L7.setBounds(5,85,10,20);
        this.add(L7);
        this.B.setBounds(65,90,80+55,20);
        this.B.addActionListener(new AscoltaBottone());
        this.add(B);
        this.L5.setBounds(5,115,80,20);
        this.add(L5);
        this.TF5.setBounds(100,115,80,20);
        this.add(TF5);
        this.L6.setBounds(5,135,80,20);
        this.add(L6);
        this.TF6.setBounds(100,135,80,20);
        this.add(TF6);
        this.setVisible(true);
        Calcola();
    }

    public void start() {
	repaint();
        Calcola();
    }

    private class AscoltaBottone implements ActionListener {
        public void actionPerformed(ActionEvent E) {
            Calcola();
        }
    }
    private void Calcola() {
      double x1 = Double.parseDouble(TF1.getText());
      double y1 = Double.parseDouble(TF2.getText());
      double x2 = Double.parseDouble(TF3.getText());
      double y2 = Double.parseDouble(TF4.getText());
      double Pendenza = (y2-y1)/(x2-x1);
      double PendenzaPercentuale = Pendenza*100;
      if((x2-x1) != 0) {
        TF5.setText(String.valueOf(Pendenza));
        TF6.setText(String.valueOf(PendenzaPercentuale));
      }
      else JOptionPane.showMessageDialog(this,"Divisione per zero...!?","Warning",2);
    }
}