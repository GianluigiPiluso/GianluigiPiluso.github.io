/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/*
 * NewJFrame.java
 *
 * Created on 20-gen-2009, 19.26.01
 */

package istogramma;
import java.io.*;
import java.lang.Math.*;
import java.awt.Graphics;
import java.awt.Color;
import javax.swing.JOptionPane;

/**
 *
 * @author Gianluigi
 */
public class NewJFrame extends javax.swing.JFrame {

    int NTDI=200; // Max. numero teorico dei dati per l'istogramma
    int NRDI=NTDI; // Numero reale di dati per l'istogramma
    double Dati[]; // Dati (letti dal file)
    double ValMax=0.0; // Massimo valore dei Dati letti
    double ValMin=0.0; // Minimo valore dei Dati letti
    double Media=0.0;
    double DeviazioneStandard=0.0;
    double SemiDispersione=0.0;
    double InizioClasse=0.0; // Valore iniziale della classe dei Dati
    double FineClasse=0.0; // Valore finale della classe dei Dati
    double IncrementoClasse=0.0; // Larghezza della classe dei Dati
    double ProbEmp[]; // Probabilità Empirica
    double ProbDensEmp[]; // Probabilità di Densità Empirica
    double ProbTeorica[]; // Probabilità Teorica
    double ProbDensTeorica[]; // Probabilità di Densità Teorica
    int NClassi=20; // Massimo numero di classi ammissibile
    int NC; // Numero di classi realmente utilizzate
    int NumeroDecimali=3; // Impostazione dei decimali rappresentabili sul form
    int Barra[]; // Frequenze per ogni barra dell'istogramma
    int ValMax_y=0; // Massima ordinata utilizzata per la grafica
    int ValMin_y=0; // Minima ordinata utilizzata per la grafica

    boolean Flag=false; // Flag utilizzato nella funzione paint (Graphics g)
    boolean AiutoInLinea=true;

    /** Creates new form NewJFrame */
    public NewJFrame() {
        initComponents();        

        Dati = new double[NTDI];
        Barra = new int [NClassi];
        ProbEmp = new double [NClassi];
        ProbDensEmp = new double [NClassi];
    }

    private void LetturaDatiIstogramma() {
        int k=0;
        String s;
        boolean Eof=false;

        try {
            FileReader In=new FileReader("Dati Istogramma.txt");
            BufferedReader BuffIn=new BufferedReader(In);
            while (!Eof) {
                s=BuffIn.readLine();
                if (s == null) Eof=true;
                else {
                Dati[k]=Float.parseFloat(s);
                  //System.out.println(Dati[k]);
                k=k+1;
                }
            } //Fine while
            BuffIn.close();
            NRDI=k;
            jTextField2.setText(String.valueOf(k));
            //System.out.println(NRDI);
        }
        catch(IOException E) {
            System.out.println("Errore di lettura nel File: Dati Istogramma.txt");
        }
    } //Fine - LetturaDatiIstogramma

    private int Approssimazione(int x) {
        int ris=1;
        int k;
        for(k=0; k<x;k++) 
            ris=10*ris;
        return ris;
    }

    private void CalcoloParametriStatistici() {
        double somma;
        int Appross;
        int k;

        NumeroDecimali=Integer.parseInt(jTextField12.getText());
        Appross=Approssimazione(NumeroDecimali);
        //System.out.println("Approssimazione: "+Appross);

        //Media
        somma=0.0;
        for (k=0; k<NRDI; k++)
            somma=somma+Dati[k];
        Media=somma/NRDI;
        Media=(int) (Media*Appross+0.5);
        Media=Media/Appross;
        jTextField5.setText(String.valueOf(Media));
        System.out.println("Media: "+Media);

        // Deviazione Standard
        somma=0.0;
        for (k=0; k<NRDI; k++)
            somma=somma+(Dati[k]-Media)*(Dati[k]-Media);
        DeviazioneStandard=Math.sqrt(somma/(NRDI-1));
        DeviazioneStandard=(int) (DeviazioneStandard*Appross+0.5);
        DeviazioneStandard=DeviazioneStandard/Appross;
        jTextField6.setText(String.valueOf(DeviazioneStandard));
        System.out.println("Deviazione Standard: "+DeviazioneStandard);

        // Massimo
        ValMax=Dati[0];
        for (k=1; k<NRDI; k++)
            if(Dati[k]>ValMax) ValMax=Dati[k];
        ValMax=(int) (ValMax*Appross+0.5);
        ValMax=ValMax/Appross;
        jTextField3.setText(String.valueOf(ValMax));
        System.out.println("Valore Massimo: "+ValMax);

        // Minimo
        ValMin=Dati[0];
        for (k=1; k<NRDI; k++)
            if(Dati[k]<ValMin) ValMin=Dati[k];
        ValMin=(int) (ValMin*Appross+0.5);
        ValMin=ValMin/Appross;
        jTextField4.setText(String.valueOf(ValMin));
        System.out.println("Valore Minimo: "+ValMin);

        //Semidispersione
        SemiDispersione=(ValMax-ValMin)/2.0;
        SemiDispersione=(int) (SemiDispersione*Appross+0.5);
        SemiDispersione=SemiDispersione/Appross;
        jTextField7.setText(String.valueOf(SemiDispersione));
        System.out.println("Semi-Dispersione: "+SemiDispersione);

        // Prima Valutazione Approssimata delle classi
        jTextField8.setText(String.valueOf(ValMin));
        jTextField9.setText(String.valueOf(ValMax));
        NC=Integer.parseInt(jTextField10.getText());
        IncrementoClasse=(ValMax-ValMin)/(1.0*NC);
        IncrementoClasse=(int) (IncrementoClasse*Appross+0.5);
        IncrementoClasse=IncrementoClasse/Appross;
        jTextField11.setText(String.valueOf(IncrementoClasse));
    } // Fine - CalcoloParametriStatistici

    private void CalcoloPreliminareClassi() {
        int k=0;
        int j=0;
        int FrequenzaClasse=0;
        int Appross;
        double x;
        double yy;

        InizioClasse=Double.parseDouble(jTextField8.getText());
        IncrementoClasse=Double.parseDouble(jTextField11.getText());

        // valutazioni del numero delle classi NC
        FineClasse=InizioClasse+IncrementoClasse;
        for(k=0; k<NClassi; k++) {
            if((FineClasse) < ValMax) {
                FineClasse=FineClasse+IncrementoClasse;
            } else {
                NC=k+1;
                break;
            }
        }
        jTextField10.setText(String.valueOf(NC));
        System.out.println("N.Classi: "+NC);

        // Calcolo delle frequenze per ogni barra dell'Istogramma
        FineClasse=InizioClasse+IncrementoClasse;
        for(j=0; j<NC; j++) {
            FrequenzaClasse=0;
            for(k=0; k<NRDI; k++) {
                if(Dati[k]<FineClasse && Dati[k]>= InizioClasse) {
                    FrequenzaClasse=FrequenzaClasse+1;
                }
            } // fine for k
            Barra[j]=FrequenzaClasse;
            InizioClasse=FineClasse;
            FineClasse=InizioClasse+IncrementoClasse;
        } // fine for j;

        // Calcolo del valore Massimo dell'ordinata servirà poi per il grafico
        // dell'Istogramma e della curva di Gauss
        ValMax_y=Barra[0];
        for(j=0; j<NC; j++)
            if(Barra[j]>ValMax_y) ValMax_y=Barra[j];

        //Riduco leggermente il valore massimo per non farlo uscire dall'area
        //grafica
        ValMax_y=ValMax_y+(int)(ValMax_y/5.0);
        if(NRDI*IncrementoClasse*FunzioneGauss(Media,Media,DeviazioneStandard)>ValMax_y)
            ValMax_y=(int) (NRDI*IncrementoClasse*FunzioneGauss(Media,Media,DeviazioneStandard)+10);

        for(j=0; j<NC; j++)
          System.out.println("Frequenze per barra: "+Barra[j]+" ---> "+(float)(Barra[j]*1.0/NRDI/IncrementoClasse));

        NumeroDecimali=Integer.parseInt(jTextField12.getText());
        Appross=Approssimazione(NumeroDecimali);
        x=FineClasse-IncrementoClasse;
        x=(int) (x*Appross+0.5);
        x=x/Appross;
        jTextField9.setText(String.valueOf(x));
        //System.out.println("Fine Classe: "+(FineClasse-IncrementoClasse));

        ValMax=Double.parseDouble(jTextField9.getText());
        ValMin=Double.parseDouble(jTextField8.getText());
    } // Fine CalcoloPreliminareClassi

    public void paint (Graphics g) {
        int x0=15;
        int y0=350;
        int LarghTela=335+89;
        int AltTela=200;
        int Max_y=0;
        int min_y=0;
        int x1=0;
        int y1=0;
        int x2=0;
        int y2=0;
        double x=0;
        double y=0;
        int j=0;
        double xx=0.0;
        double dx=0;

        g.setColor(Color.WHITE);
        g.fillRect(x0, y0, LarghTela, AltTela);

        if (Flag) {
            jButton1.setEnabled(false);
            jButton2.setEnabled(false);
            g.setColor(Color.BLACK);
            g.drawRect(x0, y0, LarghTela, AltTela);

            //System.out.println(ValMax+" "+ValMin);
            //System.out.println(ValMax_y+" "+ValMin_y);

            InizioClasse=Double.parseDouble(jTextField8.getText());
            IncrementoClasse=Double.parseDouble(jTextField11.getText());
            xx=InizioClasse;
            //Barra[0]=2;
            for(j=0; j<NC; j++) {
                x=(xx-ValMin)*LarghTela/(ValMax-ValMin);
                x1=x0+(int)x;
                y1=y0;

                xx=xx+IncrementoClasse;
                x=(xx-ValMin)*LarghTela/(ValMax-ValMin);
                //x1=x0+(x-min_x)*LarghTela/(Max_x-min_x);
                x2=x0+(int)x;
                y=(Barra[j]-ValMin_y)*AltTela/(ValMax_y-ValMin_y);
                y2=(int)y;

                //System.out.println(x1);
                //System.out.println(y1);
                //System.out.println(x2-x1);
                //System.out.println(y2);

                g.drawRect(x1, y1-y2+AltTela, (x2-x1), y2);
                Flag=false;
            } // Fine for j 

            // Probabilità Empirica
            IstogrammaGrafico();
            g.setColor(Color.RED);

            /* InizioClasse=Double.parseDouble(jTextField8.getText());
            IncrementoClasse=Double.parseDouble(jTextField11.getText());
            xx=InizioClasse;
            //Barra[0]=2;
            for(j=0; j<NC; j++) {
                x=(xx-ValMin)*LarghTela/(ValMax-ValMin);
                x1=x0+(int)x;
                y1=y0;

                xx=xx+IncrementoClasse;
                x=(xx-ValMin)*LarghTela/(ValMax-ValMin);
                //x1=x0+(x-min_x)*LarghTela/(Max_x-min_x);
                x2=x0+(int)x;
                y=(ProbDensEmp[j]-ValMin_y)*AltTela/(ValMax_y-ValMin_y);
                y2=(int)y;

                System.out.println(x1);
                System.out.println(y1);
                System.out.println(x2-x1);
                System.out.println(y2);

                g.drawRect(x1, y1-y2+AltTela, (x2-x1), y2);
                Flag=false;
            } // Fine for j */

            // Grafica Gauss
            InizioClasse=Double.parseDouble(jTextField8.getText());
            FineClasse=Double.parseDouble(jTextField9.getText());
            dx=(FineClasse-InizioClasse)/1000.0;

            xx=InizioClasse;
            do {
                //NRDI*IncrementoClasse
                y=NRDI*IncrementoClasse*FunzioneGauss(xx,Media,DeviazioneStandard);
                //System.out.println(xx+" --- "+y);
                x=(xx-ValMin)*LarghTela/(ValMax-ValMin);
                x1=x0+(int)x;
                y=(y-ValMin_y)*AltTela/(ValMax_y-ValMin_y);
                y1=(int)y;
                g.drawLine(x1, y0-y1+AltTela, x1, y0-y1+AltTela);
                xx=xx+dx;
            } while (xx < FineClasse);
        } // Fine if     
    } // Fine paint()


    private void IstogrammaGrafico() {
        int k;
        int msx=10;
        int mdx=10;
        int ms=10;
        int mi=0;

        IncrementoClasse=Double.parseDouble(jTextField11.getText());
        // Calcolo della Probabilità Empirica
        for(k=0; k<NC; k++)
            ProbEmp[k]=Barra[k]/(double)NRDI;

        // Calcolo della Densità di Probabilità Empirica
        for(k=0; k<NC; k++)
            ProbDensEmp[k]=ProbEmp[k]/IncrementoClasse;
    } // Fine IstogrammaGrafico;


    private double FunzioneGauss (double x, double M, double s) {
        double y=0.0;
        double y1=0.0;
        double y2;
        y1=1.0/(Math.sqrt(2.0*Math.PI)*s);
        y2=Math.exp(-(M-x)*(M-x)/2.0/s/s);
        y=y1*y2;
        return y;
    } // Fine FunzioneGauss
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTextField11 = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        jTextField10 = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        jTextField9 = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jTextField8 = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jTextField7 = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jTextField6 = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jTextField5 = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jTextField4 = new javax.swing.JTextField();
        jTextField3 = new javax.swing.JTextField();
        jTextField2 = new javax.swing.JTextField();
        jTextField1 = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jTextField12 = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jCheckBox1 = new javax.swing.JCheckBox();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Istogramma - G.Piluso - 2009");
        setMinimumSize(new java.awt.Dimension(450, 570));

        jTextField11.setBackground(new java.awt.Color(204, 255, 204));

        jLabel11.setText("Incremento");
        jLabel11.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 0, 51)));

        jTextField10.setText("8");
        jTextField10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField10ActionPerformed(evt);
            }
        });

        jLabel10.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel10.setText("N.Classi (<20)");

        jLabel9.setText("Classe Fin.");

        jTextField8.setBackground(new java.awt.Color(204, 255, 204));

        jLabel8.setText("Classe Iniz.");
        jLabel8.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 0, 51)));

        jLabel7.setText("SemiDispers.");

        jLabel6.setText("Dev.Standard");

        jLabel5.setText("Media");

        jLabel1.setText("Lettura Dati dal File");

        jLabel2.setText("N.Dati");

        jLabel3.setText("Val.Max");

        jLabel4.setText("Val.Min");

        jLabel12.setText("N.Dec.");
        jLabel12.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 0, 51)));

        jTextField12.setBackground(new java.awt.Color(204, 255, 204));
        jTextField12.setText("3");

        jButton1.setText("Calcolo Parametri Statistici");
        jButton1.setEnabled(false);
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setText("Calcolo delle Classi");
        jButton2.setEnabled(false);
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setText("Leggi Dati");
        jButton3.setMaximumSize(new java.awt.Dimension(79, 100));
        jButton3.setMinimumSize(new java.awt.Dimension(79, 100));
        jButton3.setPreferredSize(new java.awt.Dimension(79, 100));
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jCheckBox1.setSelected(true);
        jCheckBox1.setText("Aiuto in lInea passo passo");
        jCheckBox1.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                jCheckBox1StateChanged(evt);
            }
        });
        jCheckBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox1ActionPerformed(evt);
            }
        });

        org.jdesktop.layout.GroupLayout layout = new org.jdesktop.layout.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(layout.createSequentialGroup()
                .addContainerGap()
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                    .add(org.jdesktop.layout.GroupLayout.LEADING, jButton2, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 379, Short.MAX_VALUE)
                    .add(org.jdesktop.layout.GroupLayout.LEADING, jButton1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 379, Short.MAX_VALUE)
                    .add(org.jdesktop.layout.GroupLayout.LEADING, layout.createSequentialGroup()
                        .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(jButton3, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 151, Short.MAX_VALUE)
                            .add(jCheckBox1))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                        .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(jTextField1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 120, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(jLabel1))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(jTextField2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 51, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(jLabel2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 39, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING, false)
                            .add(jTextField12)
                            .add(jLabel12, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .add(org.jdesktop.layout.GroupLayout.LEADING, layout.createSequentialGroup()
                        .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING, false)
                            .add(jLabel3, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .add(jTextField3)
                            .add(jLabel5, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .add(jTextField5, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 67, Short.MAX_VALUE))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                        .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(layout.createSequentialGroup()
                                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                                    .add(jTextField6, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 67, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                    .add(jLabel6))
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                                    .add(jLabel7)
                                    .add(jTextField7, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 67, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                            .add(jTextField4, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(jLabel4))
                        .add(10, 10, 10))
                    .add(org.jdesktop.layout.GroupLayout.LEADING, layout.createSequentialGroup()
                        .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(jLabel8)
                            .add(jTextField8, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 67, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED, 44, Short.MAX_VALUE)
                        .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(jLabel9, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 69, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(layout.createSequentialGroup()
                                .add(2, 2, 2)
                                .add(jTextField9, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 67, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(jTextField10, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 67, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(jLabel10, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 88, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                        .add(36, 36, 36)
                        .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                            .add(org.jdesktop.layout.GroupLayout.LEADING, jLabel11, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 69, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(org.jdesktop.layout.GroupLayout.LEADING, layout.createSequentialGroup()
                                .add(2, 2, 2)
                                .add(jTextField11, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 67, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))))
                .add(61, 61, 61))
        );

        layout.linkSize(new java.awt.Component[] {jLabel6, jLabel7}, org.jdesktop.layout.GroupLayout.HORIZONTAL);

        layout.linkSize(new java.awt.Component[] {jTextField3, jTextField4, jTextField5}, org.jdesktop.layout.GroupLayout.HORIZONTAL);

        layout.linkSize(new java.awt.Component[] {jLabel3, jLabel8}, org.jdesktop.layout.GroupLayout.HORIZONTAL);

        layout.setVerticalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(layout.createSequentialGroup()
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING, false)
                    .add(layout.createSequentialGroup()
                        .add(43, 43, 43)
                        .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                            .add(layout.createSequentialGroup()
                                .add(jLabel1)
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                .add(jTextField1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                            .add(layout.createSequentialGroup()
                                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                                    .add(jLabel12)
                                    .add(jLabel2))
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                                    .add(jTextField2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                    .add(jTextField12, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))))
                    .add(org.jdesktop.layout.GroupLayout.LEADING, layout.createSequentialGroup()
                        .addContainerGap()
                        .add(jCheckBox1)
                        .add(18, 18, 18)
                        .add(jButton3, 0, 0, Short.MAX_VALUE)))
                .add(13, 13, 13)
                .add(jButton1)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                    .add(layout.createSequentialGroup()
                        .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                            .add(layout.createSequentialGroup()
                                .add(jLabel3)
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                .add(jTextField3, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                            .add(layout.createSequentialGroup()
                                .add(jLabel4, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 14, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                .add(jTextField4, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                            .add(jTextField5, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 19, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(layout.createSequentialGroup()
                                .add(jLabel5)
                                .add(25, 25, 25))
                            .add(layout.createSequentialGroup()
                                .add(jLabel6)
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                .add(jTextField6, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 19, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                            .add(layout.createSequentialGroup()
                                .add(jLabel7)
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                .add(jTextField7, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 19, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                            .add(layout.createSequentialGroup()
                                .add(jLabel8)
                                .add(25, 25, 25))
                            .add(jTextField8, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 19, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                    .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                        .add(jLabel11)
                        .add(layout.createSequentialGroup()
                            .add(1, 1, 1)
                            .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                                .add(layout.createSequentialGroup()
                                    .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                                        .add(jLabel10)
                                        .add(jLabel9))
                                    .add(25, 25, 25))
                                .add(jTextField9, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 19, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                .add(jTextField10, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 19, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                .add(jTextField11, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 19, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jButton2)
                .add(282, 282, 282))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        //System.out.println("---> Sono Entrato <---");
        CalcoloParametriStatistici();
        jButton2.setEnabled(true);
        if(AiutoInLinea==true)
            JOptionPane.showMessageDialog(null, "Puoi cambiare la clsse iniziale e l'incremento... quindi premi il bottone <Calcolo delle Classi>");
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jTextField10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField10ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField10ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        CalcoloPreliminareClassi();
        Flag=true;        
        //jButton1.setEnabled(false);
        //jButton2.setEnabled(false);
        repaint();
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
        LetturaDatiIstogramma();
        jTextField1.setText("Dati Istogramma.txt");
        jButton1.setEnabled(true);
        Flag=false;
        if(AiutoInLinea==true)
            JOptionPane.showMessageDialog(null, "Puoi cambiare il numero di decimali... quindi premi il bottone <Calcolo Parametri Statistici>");
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jCheckBox1StateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_jCheckBox1StateChanged
        // TODO add your handling code here:
        if(jCheckBox1.isSelected()) AiutoInLinea=true;
        if(!jCheckBox1.isSelected()) AiutoInLinea=false;
    }//GEN-LAST:event_jCheckBox1StateChanged

    private void jCheckBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jCheckBox1ActionPerformed

    /**
    * @param args the command line arguments
    */
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                //new NewJFrame().setVisible(true);
                NewJFrame njf = new NewJFrame();
                njf.setVisible(true);
                njf.setLocation(300, 100);
                njf.setSize(450, 570);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JCheckBox jCheckBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField10;
    private javax.swing.JTextField jTextField11;
    private javax.swing.JTextField jTextField12;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JTextField jTextField5;
    private javax.swing.JTextField jTextField6;
    private javax.swing.JTextField jTextField7;
    private javax.swing.JTextField jTextField8;
    private javax.swing.JTextField jTextField9;
    // End of variables declaration//GEN-END:variables

}

