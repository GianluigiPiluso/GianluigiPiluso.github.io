import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Toolkit;
import javax.swing.*;
import java.io.*;
import java.util.Scanner;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
//import com.itextpdf.text.Font;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Element;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Image;
import com.itextpdf.text.pdf.FontSelector;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.FileOutputStream;
import java.io.IOException;


public class VotoCondotta extends JFrame{
	int NumeroAlunni=50;
	int ContatoreAlunni=0;
	
	String NomeFile="Lista_Alunni.txt";
	String Nome_File="Condotta.dat";
	
	DatiCondotta dc;
	
    String Classe[] = new String[NumeroAlunni];
    String NomeCognomeAlunno[] = new String[NumeroAlunni];
	
	JLabel jl_classe, jl_Alunno;
	JLabel jl_Totale;
	JLabel jl_Voto;
	
	JTextField jtf_classe, jtf_Alunno;
		
	JTextArea jta_ind1,jta_ind1_1,jta_ind1_2,jta_ind1_3;
	JTextArea jta_ind2,jta_ind2_1,jta_ind2_2,jta_ind2_3;
	JTextArea jta_ind3,jta_ind3_1,jta_ind3_2,jta_ind3_3;
	JTextArea jta_ind4,jta_ind4_1,jta_ind4_2,jta_ind4_3;
	JTextArea jta_ind5,jta_ind5_1,jta_ind5_2,jta_ind5_3;
	JTextArea jta_ind6,jta_ind6_1,jta_ind6_2,jta_ind6_3,jta_ind6_4;
	JTextArea jta_ind7,jta_ind7_1,jta_ind7_2,jta_ind7_3;
	JTextArea jta_ind8,jta_ind8_1,jta_ind8_2,jta_ind8_3,jta_ind8_4,jta_ind8_5;
	
	ButtonGroup bg_ind1,bg_ind2,bg_ind3,bg_ind4,bg_ind5;
	ButtonGroup bg_ind6,bg_ind7,bg_ind8;
	ButtonGroup bg_UM;
	
	JRadioButton jr_ind1_1,jr_ind1_2,jr_ind1_3;
	JRadioButton jr_ind2_1,jr_ind2_2,jr_ind2_3;
	JRadioButton jr_ind3_1,jr_ind3_2,jr_ind3_3;
	JRadioButton jr_ind4_1,jr_ind4_2,jr_ind4_3;
	JRadioButton jr_ind5_1,jr_ind5_2,jr_ind5_3;
	JRadioButton jr_ind6_1,jr_ind6_2,jr_ind6_3,jr_ind6_4;
	JRadioButton jr_ind7_1,jr_ind7_2,jr_ind7_3;
	JRadioButton jr_ind8_1,jr_ind8_2,jr_ind8_3,jr_ind8_4,jr_ind8_5;
	JRadioButton jr_U,jr_M;
	
	JButton jb_Inizio,jb_Fine,jb_Sinistra,jb_Destra;
	JButton jb_Salva,jb_CreaPDF,jb_Calcola,jb_Cancella;
	
	Font bf =new Font("sansserif", Font.BOLD,12);
	//Font bf = new Font(Font.FontFamily.HELVETICA, 12, Font.BOLD);	
	//Costruttore del Frame VotoCondotta
	public VotoCondotta(){
		super();	
		this.setTitle("Assegnazione Voto di Condotta - GP 02/10/2010 - V.2");		
		
		//Dati Generali
		jl_classe = new JLabel("   Classe:");	
		jl_classe.setFont(bf);
		jl_classe.setBounds(5, 0, 200, 30);
		add(jl_classe);		
		jtf_classe = new JTextField("***",15);	//??? scrittura da File		
		jtf_classe.setFont(bf);
		jtf_classe.setBounds(5,26, 150, 24);
		add(jtf_classe);
		
		jl_Alunno = new JLabel("   Alunno:");	
		jl_Alunno.setFont(bf);
		jl_Alunno.setBounds(205, 0, 200, 30);
		add(jl_Alunno);		
		jtf_Alunno = new JTextField("Gianluigi Piluso",15);	//??? scrittura da File	
		jtf_Alunno.setFont(bf);
		jtf_Alunno.setBounds(205, 26, 250, 24);
		add(jtf_Alunno);
		
		//Indicatore 1
		Color colore_1 = new Color(240,250,240);
		jta_ind1 = new JTextArea("1 - Partecipazione , assiduit� e impegno al dialogo educativo");	
		jta_ind1.setFont(bf);
		jta_ind1.setLineWrap(true);
		jta_ind1.setWrapStyleWord(true);
		jta_ind1.setBackground(colore_1); 
		jta_ind1.setBorder(BorderFactory.createLineBorder(Color.black));
		jta_ind1.setBounds(5, 60, 198, 40);
		add(jta_ind1);
		
		bg_ind1 = new ButtonGroup();				
		jta_ind1_1 = new JTextArea("Gravemente compromessi");	
		jta_ind1_1.setFont(bf);
		jta_ind1_1.setLineWrap(true);
		jta_ind1_1.setWrapStyleWord(true);
		jta_ind1_1.setBackground(colore_1);
		jta_ind1_1.setBorder(BorderFactory.createLineBorder(Color.black));
		jta_ind1_1.setBounds(205, 60, 250, 20);
		add(jta_ind1_1);		
		jr_ind1_1 = new JRadioButton("1.00");	
		jr_ind1_1.setFont(bf);
		jr_ind1_1.setBounds(457, 50, 50, 40);
		add(jr_ind1_1);
		bg_ind1.add(jr_ind1_1);		

		jta_ind1_2 = new JTextArea("Scarsi rispetto al dialogo educativo e alle attivit� scolastiche , limitata disponibilit�");	
		jta_ind1_2.setFont(bf);
		jta_ind1_2.setLineWrap(true);
		jta_ind1_2.setWrapStyleWord(true);
		jta_ind1_2.setBackground(colore_1);
		jta_ind1_2.setBorder(BorderFactory.createLineBorder(Color.black));
		jta_ind1_2.setBounds(205, 82, 250, 40);
		add(jta_ind1_2);
		jr_ind1_2 = new JRadioButton("1.25");	
		jr_ind1_2.setFont(bf);
		jr_ind1_2.setBounds(457, 82, 50, 40);
		add(jr_ind1_2);
		bg_ind1.add(jr_ind1_2);		

		jta_ind1_3 = new JTextArea("Propositivi , motivati , disponibilit� e impegno nei confronti delle attivit� proposte dalla scuola");	
		jta_ind1_3.setFont(bf);
		jta_ind1_3.setLineWrap(true);
		jta_ind1_3.setWrapStyleWord(true);
		jta_ind1_3.setBackground(colore_1);
		jta_ind1_3.setBorder(BorderFactory.createLineBorder(Color.black));
		jta_ind1_3.setBounds(205, 124, 250, 50);
		add(jta_ind1_3);
		jr_ind1_3 = new JRadioButton("1.50");	
		jr_ind1_3.setFont(bf);
		jr_ind1_3.setBounds(457, 124, 50, 50);
		add(jr_ind1_3);
		bg_ind1.add(jr_ind1_3);
		
		//Indicatore 2
		Color colore_2 = new Color(253,245,230);		
		jta_ind2 = new JTextArea("2 - Svolgimento delle consegne scolastiche");	
		jta_ind2.setFont(bf);
		jta_ind2.setLineWrap(true);
		jta_ind2.setWrapStyleWord(true);
		jta_ind2.setBackground(colore_2);
		jta_ind2.setBorder(BorderFactory.createLineBorder(Color.black));
		jta_ind2.setBounds(5, 176, 198, 40);
		add(jta_ind2);
		
		bg_ind2 = new ButtonGroup();	
		jta_ind2_1 = new JTextArea("Raramente sollecitato");	
		jta_ind2_1.setFont(bf);
		jta_ind2_1.setLineWrap(true);
		jta_ind2_1.setWrapStyleWord(true);
		jta_ind2_1.setBackground(colore_2);
		jta_ind2_1.setBorder(BorderFactory.createLineBorder(Color.black));
		jta_ind2_1.setBounds(205, 176, 250, 20);
		add(jta_ind2_1);		
		jr_ind2_1 = new JRadioButton("0.50");	
		jr_ind2_1.setFont(bf);
		jr_ind2_1.setBounds(457, 176, 50, 20);
		add(jr_ind2_1);
		bg_ind2.add(jr_ind2_1);		
				
		jta_ind2_2 = new JTextArea("Assiduo / sostanzialmente autonomo");	
		jta_ind2_2.setFont(bf);
		jta_ind2_2.setLineWrap(true);
		jta_ind2_2.setWrapStyleWord(true);
		jta_ind2_2.setBackground(colore_2);
		jta_ind2_2.setBorder(BorderFactory.createLineBorder(Color.black));
		jta_ind2_2.setBounds(205, 198, 250, 20);
		add(jta_ind2_2);
		jr_ind2_2 = new JRadioButton("0.75");	
		jr_ind2_2.setFont(bf);
		jr_ind2_2.setBounds(457, 198, 50, 20);
		add(jr_ind2_2);
		bg_ind2.add(jr_ind2_2);		

		jta_ind2_3 = new JTextArea("Assiduo / autonomo / motivato");	
		jta_ind2_3.setFont(bf);
		jta_ind2_3.setLineWrap(true);
		jta_ind2_3.setWrapStyleWord(true);
		jta_ind2_3.setBackground(colore_2);
		jta_ind2_3.setBorder(BorderFactory.createLineBorder(Color.black));
		jta_ind2_3.setBounds(205, 220, 250, 20);
		add(jta_ind2_3);
		jr_ind2_3 = new JRadioButton("1.00");	
		jr_ind2_3.setFont(bf);
		jr_ind2_3.setBounds(457, 220, 50, 20);
		add(jr_ind2_3);
		bg_ind2.add(jr_ind2_3);		
		
		//Indicatore 3		
		jta_ind3 = new JTextArea("3 - Frequenza");	
		jta_ind3.setFont(bf);
		jta_ind3.setLineWrap(true);
		jta_ind3.setWrapStyleWord(true);
		jta_ind3.setBackground(colore_1);
		jta_ind3.setBorder(BorderFactory.createLineBorder(Color.black));
		jta_ind3.setBounds(5, 242, 198, 20);
		add(jta_ind3);
		
		bg_ind3 = new ButtonGroup();	
		jta_ind3_1 = new JTextArea("Saltuaria / non sempre motivata");	
		jta_ind3_1.setFont(bf);
		jta_ind3_1.setLineWrap(true);
		jta_ind3_1.setWrapStyleWord(true);
		jta_ind3_1.setBackground(colore_1);
		jta_ind3_1.setBorder(BorderFactory.createLineBorder(Color.black));
		jta_ind3_1.setBounds(205, 242, 250, 20);
		add(jta_ind3_1);		
		jr_ind3_1 = new JRadioButton("0.50");	
		jr_ind3_1.setFont(bf);
		jr_ind3_1.setBounds(457, 242, 50, 20);
		add(jr_ind3_1);
		bg_ind3.add(jr_ind3_1);		
				
		jta_ind3_2 = new JTextArea("Regolare / assenze contenute e sempre motivate");	
		jta_ind3_2.setFont(bf);
		jta_ind3_2.setLineWrap(true);
		jta_ind3_2.setWrapStyleWord(true);
		jta_ind3_2.setBackground(colore_1);
		jta_ind3_2.setBorder(BorderFactory.createLineBorder(Color.black));
		jta_ind3_2.setBounds(205, 264, 250, 40);
		add(jta_ind3_2);
		jr_ind3_2 = new JRadioButton("0.75");	
		jr_ind3_2.setFont(bf);
		jr_ind3_2.setBounds(457, 264, 50, 40);
		add(jr_ind3_2);
		bg_ind3.add(jr_ind3_2);		

		jta_ind3_3 = new JTextArea("Regolare assidua e partecipata");	
		jta_ind3_3.setFont(bf);
		jta_ind3_3.setLineWrap(true);
		jta_ind3_3.setWrapStyleWord(true);
		jta_ind3_3.setBackground(colore_1);
		jta_ind3_3.setBorder(BorderFactory.createLineBorder(Color.black));
		jta_ind3_3.setBounds(205, 306, 250, 20);
		add(jta_ind3_3);
		jr_ind3_3 = new JRadioButton("1.00");	
		jr_ind3_3.setFont(bf);
		jr_ind3_3.setBounds(457, 306, 50, 20);
		add(jr_ind3_3);
		bg_ind3.add(jr_ind3_3);
							
		//Indicatore 4		
		jta_ind4 = new JTextArea("4 - Ritardi e uscite anticipate");	
		jta_ind4.setFont(bf);
		jta_ind4.setLineWrap(true);
		jta_ind4.setWrapStyleWord(true);
		jta_ind4.setBackground(colore_2);
		jta_ind4.setBorder(BorderFactory.createLineBorder(Color.black));
		jta_ind4.setBounds(5, 328, 198, 20);
		add(jta_ind4);
		
		bg_ind4 = new ButtonGroup();	
		jta_ind4_1 = new JTextArea("Frequenti e non sempre giustificati");	
		jta_ind4_1.setFont(bf);
		jta_ind4_1.setLineWrap(true);
		jta_ind4_1.setWrapStyleWord(true);
		jta_ind4_1.setBackground(colore_2);
		jta_ind4_1.setBorder(BorderFactory.createLineBorder(Color.black));
		jta_ind4_1.setBounds(205, 328, 250, 20);
		add(jta_ind4_1);		
		jr_ind4_1 = new JRadioButton("0.50");	
		jr_ind4_1.setFont(bf);
		jr_ind4_1.setBounds(457, 328, 50, 20);
		add(jr_ind4_1);
		bg_ind4.add(jr_ind4_1);		
				
		jta_ind4_2 = new JTextArea("Frequenti ma giustificati");	
		jta_ind4_2.setFont(bf);
		jta_ind4_2.setLineWrap(true);
		jta_ind4_2.setWrapStyleWord(true);
		jta_ind4_2.setBackground(colore_2);
		jta_ind4_2.setBorder(BorderFactory.createLineBorder(Color.black));
		jta_ind4_2.setBounds(205, 350, 250, 20);
		add(jta_ind4_2);
		jr_ind4_2 = new JRadioButton("0.75");	
		jr_ind4_2.setFont(bf);
		jr_ind4_2.setBounds(457, 350, 50, 20);
		add(jr_ind4_2);
		bg_ind4.add(jr_ind4_2);		

		jta_ind4_3 = new JTextArea("Limitati , circostanziati / Assenti");	
		jta_ind4_3.setFont(bf);
		jta_ind4_3.setLineWrap(true);
		jta_ind4_3.setWrapStyleWord(true);
		jta_ind4_3.setBackground(colore_2);
		jta_ind4_3.setBorder(BorderFactory.createLineBorder(Color.black));
		jta_ind4_3.setBounds(205, 372, 250, 20);
		add(jta_ind4_3);
		jr_ind4_3 = new JRadioButton("1.00");	
		jr_ind4_3.setFont(bf);
		jr_ind4_3.setBounds(457, 372, 50, 20);
		add(jr_ind4_3);
		bg_ind4.add(jr_ind4_3);
										
		//Indicatore 5		
		jta_ind5 = new JTextArea("5 - Rispetto dell�istituzione scolastica e del Regolamento di Istituto");	
		jta_ind5.setFont(bf);
		jta_ind5.setLineWrap(true);
		jta_ind5.setWrapStyleWord(true);
		jta_ind5.setBackground(colore_1);
		jta_ind5.setBorder(BorderFactory.createLineBorder(Color.black));
		jta_ind5.setBounds(5, 394, 198, 60);
		add(jta_ind5);
		
		bg_ind5 = new ButtonGroup();	
		jta_ind5_1 = new JTextArea("Scorretto / irrispettoso / pi� volte richiamato");	
		jta_ind5_1.setFont(bf);
		jta_ind5_1.setLineWrap(true);
		jta_ind5_1.setWrapStyleWord(true);
		jta_ind5_1.setBackground(colore_1);
		jta_ind5_1.setBorder(BorderFactory.createLineBorder(Color.black));
		jta_ind5_1.setBounds(205, 394, 250, 20);
		add(jta_ind5_1);		
		jr_ind5_1 = new JRadioButton("0.50");	
		jr_ind5_1.setFont(bf);
		jr_ind5_1.setBounds(457, 394, 50, 20);
		add(jr_ind5_1);
		bg_ind5.add(jr_ind5_1);		
				
		jta_ind5_2 = new JTextArea("Alcune volte / raramente richiamato");	
		jta_ind5_2.setFont(bf);
		jta_ind5_2.setLineWrap(true);
		jta_ind5_2.setWrapStyleWord(true);
		jta_ind5_2.setBackground(colore_1);
		jta_ind5_2.setBorder(BorderFactory.createLineBorder(Color.black));
		jta_ind5_2.setBounds(205, 416, 250, 20);
		add(jta_ind5_2);
		jr_ind5_2 = new JRadioButton("0.75");	
		jr_ind5_2.setFont(bf);
		jr_ind5_2.setBounds(457, 416, 50, 20);
		add(jr_ind5_2);
		bg_ind5.add(jr_ind5_2);		

		jta_ind5_3 = new JTextArea("Corretto e rispettoso");	
		jta_ind5_3.setFont(bf);
		jta_ind5_3.setLineWrap(true);
		jta_ind5_3.setWrapStyleWord(true);
		jta_ind5_3.setBackground(colore_1);
		jta_ind5_3.setBorder(BorderFactory.createLineBorder(Color.black));
		jta_ind5_3.setBounds(205, 438, 250, 20);
		add(jta_ind5_3);
		jr_ind5_3 = new JRadioButton("1.00");	
		jr_ind5_3.setFont(bf);
		jr_ind5_3.setBounds(457, 438, 50, 20);
		add(jr_ind5_3);
		bg_ind5.add(jr_ind5_3);
				
		//Indicatore 6				
		jta_ind6 = new JTextArea("6 - Socializzazione, ruolo all�interno della classe, collaborazione attiva con insegnanti e compagni");	
		jta_ind6.setFont(bf);
		jta_ind6.setLineWrap(true);
		jta_ind6.setWrapStyleWord(true);
		jta_ind6.setBackground(colore_2);
		jta_ind6.setBorder(BorderFactory.createLineBorder(Color.black));
		jta_ind6.setBounds(5, 460, 198, 70);
		add(jta_ind6);
		
		bg_ind6 = new ButtonGroup();	
		jta_ind6_1 = new JTextArea("Ruolo indefinito / destabilizzante");	
		jta_ind6_1.setFont(bf);
		jta_ind6_1.setLineWrap(true);
		jta_ind6_1.setWrapStyleWord(true);
		jta_ind6_1.setBackground(colore_2);
		jta_ind6_1.setBorder(BorderFactory.createLineBorder(Color.black));
		jta_ind6_1.setBounds(205, 460, 250, 20);
		add(jta_ind6_1);		
		jr_ind6_1 = new JRadioButton("0.75");	
		jr_ind6_1.setFont(bf);
		jr_ind6_1.setBounds(457, 460, 50, 20);
		add(jr_ind6_1);
		bg_ind6.add(jr_ind6_1);		
				
		jta_ind6_2 = new JTextArea("Ruolo definito e sostanzialmente integrato");	
		jta_ind6_2.setFont(bf);
		jta_ind6_2.setLineWrap(true);
		jta_ind6_2.setWrapStyleWord(true);
		jta_ind6_2.setBackground(colore_2);
		jta_ind6_2.setBorder(BorderFactory.createLineBorder(Color.black));
		jta_ind6_2.setBounds(205, 482, 250, 20);
		add(jta_ind6_2);
		jr_ind6_2 = new JRadioButton("1.00");	
		jr_ind6_2.setFont(bf);
		jr_ind6_2.setBounds(457, 482, 50, 20);
		add(jr_ind6_2);
		bg_ind6.add(jr_ind6_2);		

		jta_ind6_3 = new JTextArea("Ruolo definito, positivo/ pienamente integrato");	
		jta_ind6_3.setFont(bf);
		jta_ind6_3.setLineWrap(true);
		jta_ind6_3.setWrapStyleWord(true);
		jta_ind6_3.setBackground(colore_2);
		jta_ind6_3.setBorder(BorderFactory.createLineBorder(Color.black));
		jta_ind6_3.setBounds(205, 504, 250, 40);
		add(jta_ind6_3);
		jr_ind6_3 = new JRadioButton("1.25");	
		jr_ind6_3.setFont(bf);
		jr_ind6_3.setBounds(457, 504, 50, 40);
		add(jr_ind6_3);
		bg_ind6.add(jr_ind6_3);
		
		jta_ind6_4 = new JTextArea("Ruolo definito, positivo e propositivo, impegno e aiuto verso i compagni e i docenti");	
		jta_ind6_4.setFont(bf);
		jta_ind6_4.setLineWrap(true);
		jta_ind6_4.setWrapStyleWord(true);
		jta_ind6_4.setBackground(colore_2);
		jta_ind6_4.setBorder(BorderFactory.createLineBorder(Color.black));
		jta_ind6_4.setBounds(205, 546, 250, 60);
		add(jta_ind6_4);
		jr_ind6_4 = new JRadioButton("1.50");	
		jr_ind6_4.setFont(bf);
		jr_ind6_4.setBounds(457, 546, 50, 60);
		add(jr_ind6_4);
		bg_ind6.add(jr_ind6_4);
		
		//Indicatore 7	
		jta_ind7 = new JTextArea("7 - Cultura dei valori della cittadinanza, della libert� altrui, della legalit�");	
		jta_ind7.setFont(bf);
		jta_ind7.setLineWrap(true);
		jta_ind7.setWrapStyleWord(true);
		jta_ind7.setBackground(colore_1);
		jta_ind7.setBorder(BorderFactory.createLineBorder(Color.black));
		jta_ind7.setBounds(510, 60, 198, 60);
		add(jta_ind7);
		
		bg_ind7 = new ButtonGroup();	
		jta_ind7_1 = new JTextArea("Limitata / irrispettosa");	
		jta_ind7_1.setFont(bf);
		jta_ind7_1.setLineWrap(true);
		jta_ind7_1.setWrapStyleWord(true);
		jta_ind7_1.setBackground(colore_1);
		jta_ind7_1.setBorder(BorderFactory.createLineBorder(Color.black));
		jta_ind7_1.setBounds(710, 60, 250, 20);
		add(jta_ind7_1);		
		jr_ind7_1 = new JRadioButton("0.50");	
		jr_ind7_1.setFont(bf);
		jr_ind7_1.setBounds(962, 60, 50, 20);
		add(jr_ind7_1);
		bg_ind7.add(jr_ind7_1);		
				
		jta_ind7_2 = new JTextArea("Sostanzialmente rispettosa / adeguata");	
		jta_ind7_2.setFont(bf);
		jta_ind7_2.setLineWrap(true);
		jta_ind7_2.setWrapStyleWord(true);
		jta_ind7_2.setBackground(colore_1);
		jta_ind7_2.setBorder(BorderFactory.createLineBorder(Color.black));
		jta_ind7_2.setBounds(710, 82, 250, 20);
		add(jta_ind7_2);
		jr_ind7_2 = new JRadioButton("0.75");	
		jr_ind7_2.setFont(bf);
		jr_ind7_2.setBounds(962, 82, 50, 20);
		add(jr_ind7_2);
		bg_ind7.add(jr_ind7_2);		

		jta_ind7_3 = new JTextArea("Adeguata, rispettosa con atteggiamenti di dialogo e rispetto degli altri / atteggiamenti di apertura e solidariet�");	
		jta_ind7_3.setFont(bf);
		jta_ind7_3.setLineWrap(true);
		jta_ind7_3.setWrapStyleWord(true);
		jta_ind7_3.setBackground(colore_1);
		jta_ind7_3.setBorder(BorderFactory.createLineBorder(Color.black));
		jta_ind7_3.setBounds(710, 104, 250, 60);
		add(jta_ind7_3);
		jr_ind7_3 = new JRadioButton("1.00");	
		jr_ind7_3.setFont(bf);
		jr_ind7_3.setBounds(962, 104, 50, 60);
		add(jr_ind7_3);
		bg_ind7.add(jr_ind7_3);

		//Indicatore 8	
		jta_ind8 = new JTextArea("8 - Sanzioni erogate");	
		jta_ind8.setFont(bf);
		jta_ind8.setLineWrap(true);
		jta_ind8.setWrapStyleWord(true);
		jta_ind8.setBackground(colore_2);
		jta_ind8.setBorder(BorderFactory.createLineBorder(Color.black));
		jta_ind8.setBounds(510, 168, 198, 20);
		add(jta_ind8);
		
		bg_ind8 = new ButtonGroup();	
		jta_ind8_1 = new JTextArea("Allontanamento Sanzione CdI / superiore per somma a 15 gg");	
		jta_ind8_1.setFont(bf);
		jta_ind8_1.setLineWrap(true);
		jta_ind8_1.setWrapStyleWord(true);
		jta_ind8_1.setBackground(colore_2);
		jta_ind8_1.setBorder(BorderFactory.createLineBorder(Color.black));
		jta_ind8_1.setBounds(710, 168, 250, 40);
		add(jta_ind8_1);		
		jr_ind8_1 = new JRadioButton("0.75");	
		jr_ind8_1.setFont(bf);
		jr_ind8_1.setBounds(962, 168, 50, 40);
		add(jr_ind8_1);
		bg_ind8.add(jr_ind8_1);		
				
		jta_ind8_2 = new JTextArea("Allontanamento inferiore a 15 gg");	
		jta_ind8_2.setFont(bf);
		jta_ind8_2.setLineWrap(true);
		jta_ind8_2.setWrapStyleWord(true);
		jta_ind8_2.setBackground(colore_2);
		jta_ind8_2.setBorder(BorderFactory.createLineBorder(Color.black));
		jta_ind8_2.setBounds(710, 210, 250, 20);
		add(jta_ind8_2);
		jr_ind8_2 = new JRadioButton("1.00");	
		jr_ind8_2.setFont(bf);
		jr_ind8_2.setBounds(962, 210, 50, 20);
		add(jr_ind8_2);
		bg_ind8.add(jr_ind8_2);		

		jta_ind8_3 = new JTextArea("Sanzione scolasticamente utile");	
		jta_ind8_3.setFont(bf);
		jta_ind8_3.setLineWrap(true);
		jta_ind8_3.setWrapStyleWord(true);
		jta_ind8_3.setBackground(colore_2);
		jta_ind8_3.setBorder(BorderFactory.createLineBorder(Color.black));
		jta_ind8_3.setBounds(710, 232, 250, 20);
		add(jta_ind8_3);
		jr_ind8_3 = new JRadioButton("1.50");	
		jr_ind8_3.setFont(bf);
		jr_ind8_3.setBounds(962, 232, 50, 20);
		add(jr_ind8_3);
		bg_ind8.add(jr_ind8_3);
		
		jta_ind8_4 = new JTextArea("Censura");	
		jta_ind8_4.setFont(bf);
		jta_ind8_4.setLineWrap(true);
		jta_ind8_4.setWrapStyleWord(true);
		jta_ind8_4.setBackground(colore_2);
		jta_ind8_4.setBorder(BorderFactory.createLineBorder(Color.black));
		jta_ind8_4.setBounds(710, 254, 250, 20);
		add(jta_ind8_4);
		jr_ind8_4 = new JRadioButton("1.75");	
		jr_ind8_4.setFont(bf);
		jr_ind8_4.setBounds(962, 254, 50, 20);
		add(jr_ind8_4);
		bg_ind8.add(jr_ind8_4);
		
		jta_ind8_5 = new JTextArea("Nessuna infrazione");	
		jta_ind8_5.setFont(bf);
		jta_ind8_5.setLineWrap(true);
		jta_ind8_5.setWrapStyleWord(true);
		jta_ind8_5.setBackground(colore_2);
		jta_ind8_5.setBorder(BorderFactory.createLineBorder(Color.black));
		jta_ind8_5.setBounds(710, 276, 250, 20);
		add(jta_ind8_5);
		jr_ind8_5 = new JRadioButton("2.00");	
		jr_ind8_5.setFont(bf);
		jr_ind8_5.setBounds(962, 276, 50, 20);
		add(jr_ind8_5);
		bg_ind8.add(jr_ind8_5);
		
		//Deliberato Unanimit� o Maggioranza
		bg_UM = new ButtonGroup();
		jr_U = new JRadioButton("Unanimit�");	
		jr_U.setFont(bf);
		jr_U.setBounds(710, 340, 100, 20);
		add(jr_U);
		bg_UM.add(jr_U);
		jr_M = new JRadioButton("Maggioranza");	
		jr_M.setFont(bf);
		jr_M.setBounds(810, 340, 100, 20);
		add(jr_M);
		bg_UM.add(jr_M);				
		
		Font bft =new Font("sansserif", Font.BOLD,16);
		
		jl_Totale = new JLabel("Totale Punteggio");
		jl_Totale.setFont(bft);
		jl_Totale.setBounds(810, 300, 250, 20);
		add(jl_Totale);
		
		jl_Voto = new JLabel("0.00");
		jl_Voto.setFont(bft);
		jl_Voto.setBounds(976, 300, 50, 20);
		add(jl_Voto);
		
		jb_Inizio = new JButton("<<");
		jb_Inizio.addActionListener(
			    new ActionListener() {
			        public void actionPerformed(ActionEvent e) {
			            System.out.println("Schiacciato Inizio");  // code to execute when button is pressed
			            AggiornaDatiCondotta(ContatoreAlunni);
			            BottoneInizio();
			            CancellaSelezione();
			            ScriviForm(ContatoreAlunni);
			            Calcola();
			        }
			    }
			);
		
		jb_Inizio.setFont(bf);
		jb_Inizio.setBounds(510, 26, 50, 23);
		add(jb_Inizio);
		
		jb_Sinistra = new JButton("<");
		jb_Sinistra.addActionListener(
			    new ActionListener() {
			        public void actionPerformed(ActionEvent e) {
			            System.out.println("Schiacciato Sinistra");  // code to execute when button is pressed
			            AggiornaDatiCondotta(ContatoreAlunni);
			            BottoneSinistra();
			            CancellaSelezione();
			            ScriviForm(ContatoreAlunni);
			            Calcola();
			        }
			    }
			);
		jb_Sinistra.setFont(bf);
		jb_Sinistra.setBounds(562, 26, 50, 23);
		add(jb_Sinistra);
		
		jb_Destra = new JButton(">");
		jb_Destra.addActionListener(
			    new ActionListener() {
			        public void actionPerformed(ActionEvent e) {
			            System.out.println("Schiacciato Destra");  // code to execute when button is pressed
			            AggiornaDatiCondotta(ContatoreAlunni);			            
			            BottoneDestra();
			            CancellaSelezione();
			            ScriviForm(ContatoreAlunni);
			            Calcola();
			        }
			    }
			);
		jb_Destra.setFont(bf);
		jb_Destra.setBounds(614, 26, 50, 23);
		add(jb_Destra);
		
		jb_Fine = new JButton(">>");
		jb_Fine.addActionListener(
			    new ActionListener() {
			        public void actionPerformed(ActionEvent e) {
			            System.out.println("Schiacciato Fine");  // code to execute when button is pressed
			            AggiornaDatiCondotta(ContatoreAlunni);
			            BottoneFine();
			            CancellaSelezione();
			            ScriviForm(ContatoreAlunni);
			            Calcola();
			        }
			    }
			);
		jb_Fine.setFont(bf);
		jb_Fine.setBounds(668, 26, 50, 23);
		add(jb_Fine);
		
		jb_Cancella = new JButton("Cancella Selezione");
		jb_Cancella.addActionListener(
			    new ActionListener() {
			        public void actionPerformed(ActionEvent e) {
			            System.out.println("Schiacciato Cancella Selezione");  // code to execute when button is pressed			            
			            CancellaSelezione();
			            AggiornaDatiCondotta(ContatoreAlunni);
			        }
			    }
			);
		jb_Cancella.setFont(bf);
		jb_Cancella.setBounds(618, 390, 94, 24);
		add(jb_Cancella);		

		jb_Calcola = new JButton("Calcola");
		jb_Calcola.addActionListener(
			    new ActionListener() {
			        public void actionPerformed(ActionEvent e) {
			            System.out.println("Schiacciato Calcola");  // code to execute when button is pressed
			            AggiornaDatiCondotta(ContatoreAlunni);
			            Calcola();
			        }
			    }
			);
		jb_Calcola.setFont(bf);
		jb_Calcola.setBounds(714, 390, 94, 24);
		add(jb_Calcola);		

		jb_Salva = new JButton("Salva");
		jb_Salva.addActionListener(
			    new ActionListener() {
			        public void actionPerformed(ActionEvent e) {
			            System.out.println("Schiacciato Salva");  // code to execute when button is pressed
			            AggiornaDatiCondotta(ContatoreAlunni);
			            SalvaFileCondotta();
			        }
			    }
			);
		jb_Salva.setFont(bf);
		jb_Salva.setBounds(810, 390, 94, 24);
		add(jb_Salva);

		jb_CreaPDF = new JButton("Crea PDF");
		jb_CreaPDF.addActionListener(
			    new ActionListener() {
			        public void actionPerformed(ActionEvent e) {
			            System.out.println("Schiacciato Crea PDF");  // code to execute when button is pressed
			            AggiornaDatiCondotta(ContatoreAlunni);
			            SalvaFileCondotta();
			            CreaFilePDF();
			        }
			    }
			);
		jb_CreaPDF.setFont(bf);
		jb_CreaPDF.setBounds(912, 390, 94, 24);
		add(jb_CreaPDF);
		
		NumeroAlunni=Leggi_ListaAlunni(NomeFile,NumeroAlunni);
		System.out.println("Numero di Alunni: "+NumeroAlunni);
		//ScriviCampoClasseAlunno(0);
		//dc = new DatiCondotta(NumeroAlunni);
	}// Fine - costruttore Frame
	
	public void CreaFilePDF(){
		String C="X";
        System.out.println("Stampa del file pdf: Condotta.pdf");
        //Document document = new Document(); //{};
        Document document = new Document(PageSize.A4, 36, 20, 60, 60);
        try {
            PdfWriter.getInstance(document, new FileOutputStream("Condotta.pdf"));
            document.open();
            
            for(int i=0; i<NumeroAlunni; i++){
            	Image X = Image.getInstance("Immagini/X2.gif");
            	X.scalePercent(1);
            	//img.setAbsolutePosition(200, 400);
            	//document.add(X);
            	Image Q = Image.getInstance("Immagini/Q2.gif");
            	Q.scalePercent(10);
            	
            	//import com.itextpdf.text.Font;
            	//com.itextpdf.text.Font font = new com.itextpdf.text.Font(Font.SANS_SERIF, 10, Font.BOLD);
            	com.itextpdf.text.Font font = new com.itextpdf.text.Font(com.itextpdf.text.Font.FontFamily.HELVETICA,14,Font.BOLD);
            	com.itextpdf.text.Font ff = new com.itextpdf.text.Font(com.itextpdf.text.Font.FontFamily.HELVETICA,12,Font.BOLD);
            	//document.add(new Paragraph(" "));
            	String Titolo="                       Griglia di Valutazione Comportamento";
            	//Chunk uno = new Chunk(Titolo, new Font(Font.FontFamily.HELVETICA, 14, Font.BOLD));
            	
            	Chunk uno = new Chunk(Titolo,font);
            
            	Image IIS_Orfini = Image.getInstance("Immagini/BN_IISOrfini.gif");
            	IIS_Orfini.scalePercent(30);
            	Chunk Orfini = new Chunk(IIS_Orfini,0,-10);
            	document.add(Orfini); document.add(uno);              
            	//document.add(Chunk.NEWLINE);
            	document.add(new Paragraph(" "));
            	
            	String Classe_Alunno="Classe: "+dc.Classe[i]+"      Alunno: "+dc.Nome[i];
            	Chunk Classe = new Chunk(Classe_Alunno,ff);
            	document.add(Classe);
            	document.add(new Paragraph(" "));
            	
            	PdfPTable table1 = new PdfPTable(3);
            	PdfPCell cell1 = new PdfPCell(new Paragraph("Partecipazione , assiduit� ed impegno al dialogo educativo",ff));
            	cell1.setColspan(3);
            	table1.addCell(cell1);
            	table1.addCell("Gravemente compromessi");
            	table1.addCell("1.00");
            	if(dc.Ind_1[i].equals("1.00")) table1.addCell("*");
            		else table1.addCell(" ");
            	table1.addCell("Scarsi rispetto al dialogo educativo e alle attivit� scolastiche , limitata disponibilit�");
            	table1.addCell("1.25");
            	if(dc.Ind_1[i].equals("1.25")) table1.addCell("*");
            		else table1.addCell(" ");
            	table1.addCell("Propositivi, motivati, disponibilit� ed impegno nei confronti delle attivit� proposte dalla scuola");
            	table1.addCell("1.50");
            	if(dc.Ind_1[i].equals("1.50")) table1.addCell("*");
        			else table1.addCell(" ");
            	float[] widths1 = {450f,40f,40f};
            	table1.setTotalWidth(widths1);
            	table1.setLockedWidth(true);
            	document.add(table1);

            	PdfPTable table2 = new PdfPTable(3);
            	PdfPCell cell2 = new PdfPCell(new Paragraph("Svolgimento delle consegne scolastiche",ff));
            	cell2.setColspan(3);
            	table2.addCell(cell2);
            	table2.addCell("Raramente sollecitato");
            	table2.addCell("0.50");
            	if(dc.Ind_2[i].equals("0.50")) table2.addCell("*");
        			else table2.addCell(" ");
            	table2.addCell("Assiduo / sostanzialmente autonomo");
            	table2.addCell("0.75");
            	if(dc.Ind_2[i].equals("0.75")) table2.addCell("*");
    				else table2.addCell(" ");
            	table2.addCell("Assiduo / autonomo / motivato");
            	table2.addCell("1.00");
            	if(dc.Ind_2[i].equals("1.00")) table2.addCell("*");
    				else table2.addCell(" ");            	
            	float[] widths2 = {450f,40f,40f};
            	table2.setTotalWidth(widths2);
            	table2.setLockedWidth(true);
            	document.add(table2);
            	
            	PdfPTable table3 = new PdfPTable(3);
            	PdfPCell cell3 = new PdfPCell(new Paragraph("Frequenza",ff));
            	cell3.setColspan(3);
            	table3.addCell(cell3);
            	table3.addCell("Saltuaria / non sempre motivata");
            	table3.addCell("0.50");
            	if(dc.Ind_3[i].equals("0.50")) table3.addCell("*");
    				else table3.addCell(" ");
            	table3.addCell("Regolare / assenze contenute e sempre motivate");
            	table3.addCell("0.75");
            	if(dc.Ind_3[i].equals("0.75")) table3.addCell("*");
            		else table3.addCell(" ");
            	table3.addCell("Regolare assidua e partecipata");
            	table3.addCell("1.00");
            	if(dc.Ind_3[i].equals("1.00")) table3.addCell("*");
        			else table3.addCell(" ");            	
            	float[] widths3 = {450f,40f,40f};
            	table3.setTotalWidth(widths3);
            	table3.setLockedWidth(true);
            	document.add(table3); 
            	
            	PdfPTable table4 = new PdfPTable(3);
            	PdfPCell cell4 = new PdfPCell(new Paragraph("Ritardi e uscite anticipate",ff));
            	cell4.setColspan(3);
            	table4.addCell(cell4);
            	table4.addCell("Frequenti e non sempre giustificati");
            	table4.addCell("0.50");
            	if(dc.Ind_4[i].equals("0.50")) table4.addCell("*");
    				else table4.addCell(" ");
            	table4.addCell("Frequenti ma giustificati");
            	table4.addCell("0.75");
            	if(dc.Ind_4[i].equals("0.75")) table4.addCell("*");
					else table4.addCell(" ");
            	table4.addCell("Limitati, circostanziati / assenti");
            	table4.addCell("1.00");
            	if(dc.Ind_4[i].equals("1.00")) table4.addCell("*");
					else table4.addCell(" ");            	
            	float[] widths4 = {450f,40f,40f};
            	table4.setTotalWidth(widths4);
            	table4.setLockedWidth(true);
            	document.add(table4);             	
            	
            	PdfPTable table5 = new PdfPTable(3);
            	PdfPCell cell5 = new PdfPCell(new Paragraph("Rispetto dell�Istituzione Scolastica e del Regolamento di Istituto",ff));
            	cell5.setColspan(3);
            	table5.addCell(cell5);
            	table5.addCell("Scorretto / irrispettoso / pi� volte richiamato");
            	table5.addCell("0.50");
            	if(dc.Ind_5[i].equals("0.50")) table5.addCell("*");
					else table5.addCell(" ");
            	table5.addCell("Alcune volte / raramente richiamato");
            	table5.addCell("0.75");
            	if(dc.Ind_5[i].equals("0.75")) table5.addCell("*");
					else table5.addCell(" ");
            	table5.addCell("Corretto e rispettoso");
            	table5.addCell("1.00");
            	if(dc.Ind_5[i].equals("1.00")) table5.addCell("*");
					else table5.addCell(" ");            	
            	float[] widths5 = {450f,40f,40f};
            	table5.setTotalWidth(widths5);
            	table5.setLockedWidth(true);
            	document.add(table5);            	
            	
            	PdfPTable table6 = new PdfPTable(3);
            	PdfPCell cell6 = new PdfPCell(new Paragraph("Socializzazione, ruolo all�interno della classe, collaborazione attiva con insegnanti e compagni",ff));
            	cell6.setColspan(3);
            	table6.addCell(cell6);
            	table6.addCell("Ruolo indefinito / destabilizzante");
            	table6.addCell("0.75");
            	if(dc.Ind_6[i].equals("0.75")) table6.addCell("*");
					else table6.addCell(" ");
            	table6.addCell("Ruolo definito e sostanzialmente integrato");
            	table6.addCell("1.00");
            	if(dc.Ind_6[i].equals("1.00")) table6.addCell("*");
					else table6.addCell(" ");
            	table6.addCell("Ruolo definito, positivo / pienamente integrato");
            	table6.addCell("1.25");
            	if(dc.Ind_6[i].equals("1.25")) table6.addCell("*");
					else table6.addCell(" ");
            	table6.addCell("Ruolo definito, positivo e propositivo, impegno e aiuto verso i compagni e i docenti");
            	table6.addCell("1.50");
            	if(dc.Ind_6[i].equals("1.50")) table6.addCell("*");
					else table6.addCell(" ");
            	float[] widths6 = {450f,40f,40f};
            	table6.setTotalWidth(widths6);
            	table6.setLockedWidth(true);
            	document.add(table6);            	

            	PdfPTable table7 = new PdfPTable(3);
            	PdfPCell cell7 = new PdfPCell(new Paragraph("Cultura dei valori della cittadinanza, della libert� altrui, della legalit�",ff));
            	cell7.setColspan(3);
            	table7.addCell(cell7);
            	table7.addCell("Limitata / irrispettosa");
            	table7.addCell("0.50");
            	if(dc.Ind_7[i].equals("0.50")) table7.addCell("*");
					else table7.addCell(" ");
            	table7.addCell("Sostanzialmente rispettosa / adeguata");
            	table7.addCell("0.75");
            	if(dc.Ind_7[i].equals("0.75")) table7.addCell("*");
					else table7.addCell(" ");
            	table7.addCell("Adeguata, rispettosa con atteggiamenti di dialogo e rispetto degli altri / atteggiamenti di apertura e solidariet�");
            	table7.addCell("1.00");
            	if(dc.Ind_7[i].equals("1.00")) table7.addCell("*");
					else table7.addCell(" ");            	
            	float[] widths7 = {450f,40f,40f};
            	table7.setTotalWidth(widths7);
            	table7.setLockedWidth(true);
            	document.add(table7);

            	PdfPTable table8 = new PdfPTable(3);
            	PdfPCell cell8 = new PdfPCell(new Paragraph("Sanzioni erogate",ff));
            	cell8.setColspan(3);
            	table8.addCell(cell8);
            	table8.addCell("Allontanamento Sanzione CdI / superiore per somma a 15 gg.");
            	table8.addCell("0.75");
            	if(dc.Ind_8[i].equals("0.75")) table8.addCell("*");
					else table8.addCell(" ");
            	table8.addCell("Allontanamento inferiore a 15 gg.");
            	table8.addCell("1.00");
            	if(dc.Ind_8[i].equals("1.00")) table8.addCell("*");
					else table8.addCell(" ");
            	table8.addCell("Sanzione scolasticamente utile");
            	table8.addCell("1.50");
            	if(dc.Ind_8[i].equals("1.50")) table8.addCell("*");
					else table8.addCell(" ");
            	table8.addCell("Censura");
            	table8.addCell("1.75");
            	if(dc.Ind_8[i].equals("1.75")) table8.addCell("*");
				else table8.addCell(" ");
            	table8.addCell("Nessuna infrazione");
            	table8.addCell("2.00");
            	if(dc.Ind_8[i].equals("2.00")) table8.addCell("*");
				else table8.addCell(" ");
            	float[] widths8 = {450f,40f,40f};
            	table8.setTotalWidth(widths8);
            	table8.setLockedWidth(true);
            	document.add(table8);
            	
            	String Notes="";
            	PdfPTable table9 = new PdfPTable(3);
            	if(dc.UnanimitaMaggioranza[i].equals("Unanimit�")) Notes="Deliberato all'Unanimit�";
            	if(dc.UnanimitaMaggioranza[i].equals("Maggioranza")) Notes="Deliberato a Maggioranza";
            	Notes = Notes + "                            " + "Voto Totale Condotta...";
            	PdfPCell cell9 = new PdfPCell(new Paragraph(Notes,ff));
            	cell9.setColspan(0);
            	cell9.setHorizontalAlignment(Element.ALIGN_RIGHT);
            	table9.addCell(cell9);
            		//ScriviForm(i);
            	String voto="";
            		voto = Float.toString(Calcola2(i));
            		Paragraph p = new Paragraph(voto,font);
            		table9.addCell(p);
            		table9.addCell(" ");
            	float[] widths9 = {450f,40f,40f};
            	table9.setTotalWidth(widths9);
            	table9.setLockedWidth(true);
            	document.add(table9);
            	
            	document.newPage();            	
            }//Fine for i
            document.close();   
        } catch (DocumentException de) {
            System.err.println(de.getMessage());
        } catch (IOException ioe) {
            System.err.println(ioe.getMessage());
        }
	}//Fine - CreaPDF

	public void CancellaSelezione(){
		bg_ind1.clearSelection();
		bg_ind2.clearSelection();
		bg_ind3.clearSelection();
		bg_ind4.clearSelection();
		bg_ind5.clearSelection();
		bg_ind6.clearSelection();
		bg_ind7.clearSelection();
		bg_ind8.clearSelection();
		bg_UM.clearSelection();
	}
	
	public float Calcola2(int i){
		float Somma=0;
		Somma=Somma+Float.parseFloat(dc.Ind_1[i]);
		Somma=Somma+Float.parseFloat(dc.Ind_2[i]);		
		Somma=Somma+Float.parseFloat(dc.Ind_3[i]);
		Somma=Somma+Float.parseFloat(dc.Ind_4[i]);
		Somma=Somma+Float.parseFloat(dc.Ind_5[i]);
		Somma=Somma+Float.parseFloat(dc.Ind_6[i]);
		Somma=Somma+Float.parseFloat(dc.Ind_7[i]);
		Somma=Somma+Float.parseFloat(dc.Ind_8[i]);		
		return Somma;
	}
	
	public void Calcola(){
		float Somma=0;
        if(jr_ind1_1.isSelected()) Somma=Somma+Float.parseFloat(jr_ind1_1.getText());        	
        if(jr_ind1_2.isSelected()) Somma=Somma+Float.parseFloat(jr_ind1_2.getText());
        if(jr_ind1_3.isSelected()) Somma=Somma+Float.parseFloat(jr_ind1_3.getText());

        if(jr_ind2_1.isSelected()) Somma=Somma+Float.parseFloat(jr_ind2_1.getText());
        if(jr_ind2_2.isSelected()) Somma=Somma+Float.parseFloat(jr_ind2_2.getText());
        if(jr_ind2_3.isSelected()) Somma=Somma+Float.parseFloat(jr_ind2_3.getText());        

        if(jr_ind3_1.isSelected()) Somma=Somma+Float.parseFloat(jr_ind3_1.getText());
        if(jr_ind3_2.isSelected()) Somma=Somma+Float.parseFloat(jr_ind3_2.getText());
        if(jr_ind3_3.isSelected()) Somma=Somma+Float.parseFloat(jr_ind3_3.getText());
        
        if(jr_ind4_1.isSelected()) Somma=Somma+Float.parseFloat(jr_ind4_1.getText());
        if(jr_ind4_2.isSelected()) Somma=Somma+Float.parseFloat(jr_ind4_2.getText());
        if(jr_ind4_3.isSelected()) Somma=Somma+Float.parseFloat(jr_ind4_3.getText());
        
        if(jr_ind5_1.isSelected()) Somma=Somma+Float.parseFloat(jr_ind5_1.getText());
        if(jr_ind5_2.isSelected()) Somma=Somma+Float.parseFloat(jr_ind5_2.getText());
        if(jr_ind5_3.isSelected()) Somma=Somma+Float.parseFloat(jr_ind5_3.getText());
        
        if(jr_ind6_1.isSelected()) Somma=Somma+Float.parseFloat(jr_ind6_1.getText());
        if(jr_ind6_2.isSelected()) Somma=Somma+Float.parseFloat(jr_ind6_2.getText());
        if(jr_ind6_3.isSelected()) Somma=Somma+Float.parseFloat(jr_ind6_3.getText());
        if(jr_ind6_4.isSelected()) Somma=Somma+Float.parseFloat(jr_ind6_4.getText());
        
        if(jr_ind7_1.isSelected()) Somma=Somma+Float.parseFloat(jr_ind7_1.getText());
        if(jr_ind7_2.isSelected()) Somma=Somma+Float.parseFloat(jr_ind7_2.getText());
        if(jr_ind7_3.isSelected()) Somma=Somma+Float.parseFloat(jr_ind7_3.getText());            
        
        if(jr_ind8_1.isSelected()) Somma=Somma+Float.parseFloat(jr_ind8_1.getText());
        if(jr_ind8_2.isSelected()) Somma=Somma+Float.parseFloat(jr_ind8_2.getText());
        if(jr_ind8_3.isSelected()) Somma=Somma+Float.parseFloat(jr_ind8_3.getText());
        if(jr_ind8_4.isSelected()) Somma=Somma+Float.parseFloat(jr_ind8_4.getText());
        if(jr_ind8_5.isSelected()) Somma=Somma+Float.parseFloat(jr_ind8_5.getText());
                
		jl_Voto.setText(Float.toString(Somma));
	}
	
	public void ScriviForm(int i){
		//CancellaSelezione();
		System.out.println(">>>> "+i+"    "+dc.Ind_1[i]);

		if(dc.Ind_1[i] != null) {
			if(dc.Ind_1[i].equals("1.00")) jr_ind1_1.setSelected(true);
			if(dc.Ind_1[i].equals("1.25")) jr_ind1_2.setSelected(true);
			if(dc.Ind_1[i].equals("1.50")) jr_ind1_3.setSelected(true);
		}
		if(dc.Ind_2[i] != null) {
			if(dc.Ind_2[i].equals("0.50")) jr_ind2_1.setSelected(true);
			if(dc.Ind_2[i].equals("0.75")) jr_ind2_2.setSelected(true);
			if(dc.Ind_2[i].equals("1.00")) jr_ind2_3.setSelected(true);
		}		
		if(dc.Ind_3[i] != null) {
			if(dc.Ind_3[i].equals("0.50")) jr_ind3_1.setSelected(true);
			if(dc.Ind_3[i].equals("0.75")) jr_ind3_2.setSelected(true);
			if(dc.Ind_3[i].equals("1.00")) jr_ind3_3.setSelected(true);
		}		
		if(dc.Ind_4[i] != null) {
			if(dc.Ind_4[i].equals("0.50")) jr_ind4_1.setSelected(true);
			if(dc.Ind_4[i].equals("0.75")) jr_ind4_2.setSelected(true);
			if(dc.Ind_4[i].equals("1.00")) jr_ind4_3.setSelected(true);
		}
		if(dc.Ind_5[i] != null) {
			if(dc.Ind_5[i].equals("0.50")) jr_ind5_1.setSelected(true);
			if(dc.Ind_5[i].equals("0.75")) jr_ind5_2.setSelected(true);
			if(dc.Ind_5[i].equals("1.00")) jr_ind5_3.setSelected(true);
		}		
		if(dc.Ind_6[i] != null) {
			if(dc.Ind_6[i].equals("0.75")) jr_ind6_1.setSelected(true);
			if(dc.Ind_6[i].equals("1.00")) jr_ind6_2.setSelected(true);
			if(dc.Ind_6[i].equals("1.25")) jr_ind6_3.setSelected(true);
			if(dc.Ind_6[i].equals("1.50")) jr_ind6_4.setSelected(true);
		}		
		if(dc.Ind_7[i] != null) {
			if(dc.Ind_7[i].equals("0.50")) jr_ind7_1.setSelected(true);
			if(dc.Ind_7[i].equals("0.75")) jr_ind7_2.setSelected(true);
			if(dc.Ind_7[i].equals("1.00")) jr_ind7_3.setSelected(true);
		}		
		if(dc.Ind_8[i] != null) {
			if(dc.Ind_8[i].equals("0.75")) jr_ind8_1.setSelected(true);
			if(dc.Ind_8[i].equals("1.00")) jr_ind8_2.setSelected(true);
			if(dc.Ind_8[i].equals("1.50")) jr_ind8_3.setSelected(true);
			if(dc.Ind_8[i].equals("1.75")) jr_ind8_4.setSelected(true);
			if(dc.Ind_8[i].equals("2.00")) jr_ind8_5.setSelected(true);
		}
		if(dc.UnanimitaMaggioranza[i] != null) {
			if(dc.UnanimitaMaggioranza[i].equals("Unanimit�")) jr_U.setSelected(true);
			if(dc.UnanimitaMaggioranza[i].equals("Maggioranza")) jr_M.setSelected(true);
		}		
	}//Fine - ScriviForm
	
	public void AggiornaDatiCondotta(int i){
		dc.Classe[i]=Classe[i];
        dc.Nome[i]=NomeCognomeAlunno[i];

        if(jr_ind1_1.isSelected()) dc.Ind_1[i]=jr_ind1_1.getText();
        if(jr_ind1_2.isSelected()) dc.Ind_1[i]=jr_ind1_2.getText();
        if(jr_ind1_3.isSelected()) dc.Ind_1[i]=jr_ind1_3.getText();

        if(jr_ind2_1.isSelected()) dc.Ind_2[i]=jr_ind2_1.getText();
        if(jr_ind2_2.isSelected()) dc.Ind_2[i]=jr_ind2_2.getText();
        if(jr_ind2_3.isSelected()) dc.Ind_2[i]=jr_ind2_3.getText();
        
        if(jr_ind3_1.isSelected()) dc.Ind_3[i]=jr_ind3_1.getText();
        if(jr_ind3_2.isSelected()) dc.Ind_3[i]=jr_ind3_2.getText();
        if(jr_ind3_3.isSelected()) dc.Ind_3[i]=jr_ind3_3.getText();
        
        if(jr_ind4_1.isSelected()) dc.Ind_4[i]=jr_ind4_1.getText();
        if(jr_ind4_2.isSelected()) dc.Ind_4[i]=jr_ind4_2.getText();
        if(jr_ind4_3.isSelected()) dc.Ind_4[i]=jr_ind4_3.getText();
        
        if(jr_ind5_1.isSelected()) dc.Ind_5[i]=jr_ind5_1.getText();
        if(jr_ind5_2.isSelected()) dc.Ind_5[i]=jr_ind5_2.getText();
        if(jr_ind5_3.isSelected()) dc.Ind_5[i]=jr_ind5_3.getText();
        
        if(jr_ind6_1.isSelected()) dc.Ind_6[i]=jr_ind6_1.getText();
        if(jr_ind6_2.isSelected()) dc.Ind_6[i]=jr_ind6_2.getText();
        if(jr_ind6_3.isSelected()) dc.Ind_6[i]=jr_ind6_3.getText();
        if(jr_ind6_4.isSelected()) dc.Ind_6[i]=jr_ind6_4.getText();
        
        if(jr_ind7_1.isSelected()) dc.Ind_7[i]=jr_ind7_1.getText();
        if(jr_ind7_2.isSelected()) dc.Ind_7[i]=jr_ind7_2.getText();
        if(jr_ind7_3.isSelected()) dc.Ind_7[i]=jr_ind7_3.getText();            
        
        if(jr_ind8_1.isSelected()) dc.Ind_8[i]=jr_ind8_1.getText();
        if(jr_ind8_2.isSelected()) dc.Ind_8[i]=jr_ind8_2.getText();
        if(jr_ind8_3.isSelected()) dc.Ind_8[i]=jr_ind8_3.getText();
        if(jr_ind8_4.isSelected()) dc.Ind_8[i]=jr_ind8_4.getText();
        if(jr_ind8_5.isSelected()) dc.Ind_8[i]=jr_ind8_5.getText();
        
        if(jr_U.isSelected()) dc.UnanimitaMaggioranza[i]=jr_U.getText();
        if(jr_M.isSelected()) dc.UnanimitaMaggioranza[i]=jr_M.getText();        
	}//Fine - AggiornaDatiCondotta
	
	public void SalvaFileCondotta() {
		String Riga;
		FileWriter f_out;
		System.out.println("---> "+NumeroAlunni);
		try {
			f_out= new FileWriter("Condotta.dat");
			for (int i = 0; i < NumeroAlunni; i++) {
				Riga = "";
				Riga = dc.Classe[i] + "|" + dc.Nome[i] + "|" + dc.Ind_1[i] + "|" + dc.Ind_2[i] + "|";
				Riga = Riga + dc.Ind_3[i] + "|" + dc.Ind_4[i] + "|" + dc.Ind_5[i] + "|";
				Riga = Riga + dc.Ind_6[i] + "|" + dc.Ind_7[i] + "|" + dc.Ind_8[i] + "|";
				Riga = Riga + dc.UnanimitaMaggioranza[i] + "\r\n";				
				f_out.write(Riga);
			}
			f_out.close();
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}//Fine - SalvaFileCondotta
	
	public void BottoneInizio(){
		ContatoreAlunni=0;
		ScriviCampoClasseAlunno(ContatoreAlunni);
	}

	public void BottoneFine(){
		ContatoreAlunni=NumeroAlunni-1;
		ScriviCampoClasseAlunno(ContatoreAlunni);
	}

	public void BottoneSinistra(){
		if(ContatoreAlunni <= 0) ContatoreAlunni=0;
		   else ContatoreAlunni=ContatoreAlunni-1;
		ScriviCampoClasseAlunno(ContatoreAlunni);
	}
	
	public void BottoneDestra(){
		if(ContatoreAlunni >= NumeroAlunni-1) ContatoreAlunni=NumeroAlunni-1;
		   else ContatoreAlunni=ContatoreAlunni+1;
		ScriviCampoClasseAlunno(ContatoreAlunni);
	}
	
	public void ScriviCampoClasseAlunno(int ContatoreAlunno){
		jtf_classe.setText(Classe[ContatoreAlunno]);
		jtf_Alunno.setText(NomeCognomeAlunno[ContatoreAlunno]);
	}//Fine - ScriviCampoClasseAlunno
	
	public int Leggi_ListaAlunni(String NomeFile, int NumeroAlunni) {
		Scanner x,y;
	    //String Classe[] = new String[NumeroAlunni];
	    //String NomeCognomeAlunno[] = new String[NumeroAlunni];
	    //int NumeroAlunni=0;
		
        try{
            x=new Scanner(new File(NomeFile));
            int i=0;
            String Nome;
            while(x.hasNext()){
                Nome =x.nextLine();
                System.out.println(i+1+" - "+Nome);
                //s[i]=Nome;
                int k=Nome.indexOf(';');
                Classe[i]=Nome.substring(0,k);                
                NomeCognomeAlunno[i]=Nome.substring(k+1,Nome.length());                 
                i=i+1;
            }           
            NumeroAlunni=i;
            x.close();
            dc = new DatiCondotta(NumeroAlunni);
            for(int ii=0; ii<NumeroAlunni; ii++) {
            	//dc.Classe[ii]=Classe[ii];
            	//dc.Nome[ii]=NomeCognomeAlunno[ii];
            	AggiornaDatiCondotta(ii);
            	System.out.println(dc.Classe[ii]+" --- "+dc.Nome[ii]);
            }
            ScriviCampoClasseAlunno(0);
        }
        catch(Exception e){
            System.out.println("Leggi_ListaAlunni: Non ho trovato nessun File");            
            JOptionPane.showMessageDialog(null, "Non ho trovato il File ("+ NomeFile +" - default)", "Attenzione File Mancante", JOptionPane.ERROR_MESSAGE);
            NumeroAlunni=0;
            if(NomeFile.equals("Lista_Alunni.txt")) System.exit(0);
        }
        
        try{
            y=new Scanner(new File(Nome_File));
            int i=0;
            String Riga;
            while(y.hasNext()){
                Riga =y.nextLine();
                Decodifica(i,Riga);
                //System.out.println(i+1+" - "+Nome);
                //s[i]=Nome;
                //int k=Nome.indexOf(';');
                //Classe[i]=Nome.substring(0,k);
                //NomeCognomeAlunno[i]=Nome.substring(k+1,Nome.length());                
                i=i+1;
            }           
            //NumeroAlunni=i;
            y.close();
            ScriviForm(0);
            Calcola();
            //ScriviCampoClasseAlunno(0);        	
        }
        catch(Exception e){
            System.out.println("Leggi_ListaAlunni: Non ho trovato nessun File");            
            JOptionPane.showMessageDialog(null, "Non ho trovato il File ("+ Nome_File +" - default)", "Attenzione File Mancante", JOptionPane.ERROR_MESSAGE);
            //NumeroAlunni=0;
            //if(NomeFile.equals("Lista_Alunni.txt")) System.exit(0);
        } 
        
        return(NumeroAlunni);
	}// Fine - Leggi_ListaAlunni
	
    public void Decodifica(int k, String riga) {
        int j=0;
        int t=0;
        //String riga = recupero.getRiga(k);
        
        j = riga.indexOf('|');
        String Classe = riga.substring(0, j);
        dc.Classe[k]=Classe;

        t=j+1;
        riga=riga.substring(t, riga.length());
        //System.out.println("+++"+riga);
        j = riga.indexOf('|');        
        String Nome = riga.substring(0, j);
        dc.Nome[k]=Nome;

        t=j+1;
        riga=riga.substring(t, riga.length());
        j = riga.indexOf('|');
        dc.Ind_1[k] = riga.substring(0, j);

        t=j+1;
        riga=riga.substring(t, riga.length());
        j = riga.indexOf('|');
        dc.Ind_2[k]= riga.substring(0, j);

        t=j+1;
        riga=riga.substring(t, riga.length());
        j = riga.indexOf('|');
        dc.Ind_3[k] = riga.substring(0, j);

        t=j+1;
        riga=riga.substring(t, riga.length());
        j = riga.indexOf('|');
        dc.Ind_4[k] = riga.substring(0, j);

        t=j+1;
        riga=riga.substring(t, riga.length());
        j = riga.indexOf('|');
        dc.Ind_5[k] = riga.substring(0, j);

        t=j+1;
        riga=riga.substring(t, riga.length());
        j = riga.indexOf('|');
        dc.Ind_6[k] = riga.substring(0, j);

        t=j+1;
        riga=riga.substring(t, riga.length());
        j = riga.indexOf('|');
        dc.Ind_7[k] = riga.substring(0, j);

        t=j+1;
        riga=riga.substring(t, riga.length());
        j = riga.indexOf('|');  
        dc.Ind_8[k] = riga.substring(0, j);
        
        t=j+1;
        riga=riga.substring(t, riga.length());
        j = riga.indexOf('|');  
        dc.UnanimitaMaggioranza[k] = riga.substring(0, riga.length());        

        //ScriviStrutturaDati(k, xCL, xCCL, xCCAL, xCEL, xCLSL, xCAEL, xCAL, xVPL, xTVL, xVL, Arg);
    }//Fine - Decodifica

	public static void main(String[] args) {
		VotoCondotta f=new VotoCondotta();
		f.setLayout(null);
		f.setDefaultCloseOperation(f.EXIT_ON_CLOSE);
		f.setSize(1020, 650);
		//f.getContentPane().setBackground(new Color(250,235,215));
		//Centra la finestra
        Dimension screenSize =Toolkit.getDefaultToolkit().getScreenSize();
        Dimension frameSize = f.getSize();
        f.setLocation((screenSize.width - frameSize.width) / 2, (screenSize.height - frameSize.height) / 2);
		
        f.setVisible(true);
	}

	
	
	class DatiCondotta {
		String Classe[];
		String Nome[];
		String Ind_1[];
		String Ind_2[];
		String Ind_3[];
		String Ind_4[];
		String Ind_5[];
		String Ind_6[];
		String Ind_7[];
		String Ind_8[];
		String UnanimitaMaggioranza[];
		
		public DatiCondotta(int NumeroAlunni){
		Classe = new String[NumeroAlunni];
		Nome   = new String[NumeroAlunni];
		Ind_1 = new String[NumeroAlunni];
		Ind_2 = new String[NumeroAlunni];
		Ind_3 = new String[NumeroAlunni];
		Ind_4 = new String[NumeroAlunni];
		Ind_5 = new String[NumeroAlunni];		
		Ind_6 = new String[NumeroAlunni];		
		Ind_7 = new String[NumeroAlunni];
		Ind_8 = new String[NumeroAlunni];
		UnanimitaMaggioranza = new String[NumeroAlunni];
		}
	}
}
